<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Hala tuju

Murid belajar menghantar bola dengan tepat ke sasaran.

## Metrik

Murid yang melengkapkan Kuiz Juara Hantaran setiap minggu
