import { useState } from "react";
import dadaImg from "@/assets/teknik-dada-betul.jpg";
import lantunImg from "@/assets/teknik-lantun.jpg";
import salahImg from "@/assets/teknik-salah.jpg";
import { Button } from "@/components/ui/button";
import { markDone } from "@/lib/progress";
import { play } from "@/lib/sound";
import { cn } from "@/lib/utils";

type Pic = { id: "dada" | "lantun" | "salah"; src: string; alt: string };

const PICS: Pic[] = [
  { id: "salah", src: salahImg, alt: "Murid membaling dengan satu tangan sambil memandang ke sisi" },
  { id: "dada", src: dadaImg, alt: "Murid memegang bola di paras dada dan memandang sasaran" },
  { id: "lantun", src: lantunImg, alt: "Murid menghantar bola yang melantun di lantai kepada rakan" },
];

const ROUNDS: { q: string; answer: Pic["id"]; why: string }[] = [
  {
    q: "Gambar manakah menunjukkan hantaran dada yang BETUL?",
    answer: "dada",
    why: "Bola di paras dada, kedua-dua tangan di belakang bola, kaki melangkah dan mata melihat sasaran.",
  },
  {
    q: "Gambar manakah menunjukkan hantaran LANTUN?",
    answer: "lantun",
    why: "Bola ditolak ke lantai supaya melantun sekali kepada rakan — sukar dipintas lawan.",
  },
  {
    q: "Gambar manakah menunjukkan KESILAPAN semasa menghantar?",
    answer: "salah",
    why: "Mata tidak melihat sasaran dan kaki rapat — bola mudah tersasar.",
  },
];

export function PictureChoice() {
  const [round, setRound] = useState(0);
  const [picked, setPicked] = useState<Pic["id"] | null>(null);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  const r = ROUNDS[round]!;

  const choose = (id: Pic["id"]) => {
    if (picked) return;
    setPicked(id);
    const ok = id === r.answer;
    if (ok) setScore((s) => s + 1);
    play(ok ? "correct" : "wrong");
  };

  const next = () => {
    if (round + 1 >= ROUNDS.length) {
      setFinished(true);
      markDone("kenal-teknik");
      play("win");
      return;
    }
    setRound(round + 1);
    setPicked(null);
  };

  const restart = () => {
    setRound(0);
    setPicked(null);
    setScore(0);
    setFinished(false);
  };

  if (finished) {
    return (
      <div className="animate-pop rounded-2xl bg-mint p-6 text-center">
        <p className="text-5xl" aria-hidden>🎉</p>
        <p className="mt-2 font-display text-2xl font-bold text-mint-foreground">
          Kamu betul {score} daripada {ROUNDS.length}!
        </p>
        <p className="mt-1">
          {score === ROUNDS.length ? "Hebat! Kamu kenal teknik yang betul." : "Bagus! Cuba lagi untuk dapat semua betul."}
        </p>
        <Button className="mt-4" variant="soft" size="big" onClick={restart}>
          Cuba Lagi
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-3 flex items-center justify-between gap-3">
        <p className="font-display text-xl font-bold text-primary-deep">{r.q}</p>
        <span className="shrink-0 rounded-full bg-secondary px-3 py-1 text-sm font-bold">
          {round + 1}/{ROUNDS.length}
        </span>
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        {PICS.map((p, i) => {
          const isAns = p.id === r.answer;
          const state = picked ? (isAns ? "right" : picked === p.id ? "wrong" : "idle") : "idle";
          return (
            <button
              key={p.id}
              type="button"
              onClick={() => choose(p.id)}
              disabled={!!picked}
              className={cn(
                "group relative overflow-hidden rounded-2xl border-4 bg-card text-left transition-all",
                state === "right" && "border-success",
                state === "wrong" && "animate-wiggle border-coral",
                state === "idle" && "border-border hover:-translate-y-1 hover:border-primary",
              )}
              aria-label={`Gambar ${String.fromCharCode(65 + i)}: ${p.alt}`}
            >
              <img src={p.src} alt={p.alt} width={1024} height={1024} loading="lazy" className="aspect-square w-full object-cover" />
              <span className="absolute left-2 top-2 grid size-9 place-items-center rounded-full bg-card font-display text-lg font-bold text-primary-deep shadow-card">
                {String.fromCharCode(65 + i)}
              </span>
              {state === "right" && <span className="absolute right-2 top-2 rounded-full bg-success px-2.5 py-1 text-sm font-bold text-success-foreground">✓ Betul</span>}
              {state === "wrong" && <span className="absolute right-2 top-2 rounded-full bg-coral px-2.5 py-1 text-sm font-bold text-primary-foreground">✗ Salah</span>}
            </button>
          );
        })}
      </div>
      {picked && (
        <div className={cn("animate-pop mt-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl p-4", picked === r.answer ? "bg-mint" : "bg-coral-soft")}>
          <p className="text-lg">
            <strong>{picked === r.answer ? "Betul! " : "Belum tepat. "}</strong>
            {r.why}
          </p>
          <Button variant="game" size="big" onClick={next}>
            {round + 1 >= ROUNDS.length ? "Lihat Keputusan" : "Soalan Seterusnya"}
          </Button>
        </div>
      )}
    </div>
  );
}
