import { useState, type DragEvent } from "react";
import { Button } from "@/components/ui/button";
import { play } from "@/lib/sound";
import { cn } from "@/lib/utils";

const PAIRS = [
  { id: "pegang", label: "Pegang bola", desc: "Kedua-dua tangan di sisi bola, ibu jari di belakang, bola di paras dada." },
  { id: "lihat", label: "Lihat sasaran", desc: "Mata fokus pada rakan atau sasaran sebelum bola dilepaskan." },
  { id: "langkah", label: "Langkah kaki", desc: "Satu kaki melangkah ke hadapan ke arah sasaran." },
  { id: "lajak", label: "Ikut lajak", desc: "Tangan diluruskan ke arah sasaran selepas bola dilepaskan." },
];
const ORDER = [2, 0, 3, 1];

/** Drag (or tap) a technique chip onto its matching description. */
export function MatchDrag() {
  const [placed, setPlaced] = useState<Record<string, string>>({});
  const [sel, setSel] = useState<string | null>(null);
  const [msg, setMsg] = useState("Seret teknik ke penerangan yang betul. Boleh juga tekan teknik, kemudian tekan penerangan.");
  const used = new Set(Object.values(placed));
  const done = Object.keys(placed).length === PAIRS.length;

  const drop = (slot: string, chip: string | null) => {
    if (!chip || placed[slot]) return;
    if (chip === slot) {
      setPlaced({ ...placed, [slot]: chip }); play("correct");
      setMsg(Object.keys(placed).length + 1 === PAIRS.length ? "Hebat! Semua padanan betul! 🎉" : "Betul! Teruskan. ✅");
    } else { play("wrong"); setMsg("Belum tepat. Baca penerangan sekali lagi dan cuba semula. 💪"); }
    setSel(null);
  };

  return (
    <div className="card-fun p-5">
      <div className="flex flex-wrap gap-2" aria-label="Teknik">
        {PAIRS.filter((p) => !used.has(p.id)).map((p) => (
          <button key={p.id} type="button" draggable
            onDragStart={(e: DragEvent) => e.dataTransfer.setData("text/plain", p.id)}
            onClick={() => { setSel(p.id); play("click"); }} aria-pressed={sel === p.id}
            className={cn("cursor-grab rounded-full border-4 px-4 py-2 font-bold", sel === p.id ? "border-primary bg-sunny" : "border-border bg-card")}>
            {p.label}
          </button>
        ))}
      </div>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {ORDER.map((i) => { const p = PAIRS[i]!; const ok = placed[p.id];
          return (
            <button key={p.id} type="button" onClick={() => drop(p.id, sel)}
              onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); drop(p.id, e.dataTransfer.getData("text/plain")); }}
              className={cn("min-h-24 rounded-2xl border-4 border-dashed p-4 text-left", ok ? "border-success bg-mint" : "border-border bg-card")}>
              <p>{p.desc}</p>
              <p className="mt-2 font-display font-bold text-primary-deep">{ok ? `✓ ${p.label}` : "Letak teknik di sini"}</p>
            </button>
          ); })}
      </div>
      <p className="mt-4 rounded-2xl bg-secondary p-3 font-semibold" aria-live="polite">{msg}</p>
      {done && <Button className="mt-3" variant="soft" size="big" onClick={() => { setPlaced({}); setMsg("Cuba sekali lagi!"); }}>Cuba Semula</Button>}
    </div>
  );
}
