import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, UserRound, Volume2, VolumeX, X } from "lucide-react";
import { useState } from "react";
import { PAGES, pageIndex } from "@/lib/pages";
import { isStepComplete, percentComplete, useProgress } from "@/lib/progress";
import { setMuted, useMuted } from "@/lib/sound";
import { cn } from "@/lib/utils";

export function SiteHeader() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const current = pageIndex(pathname);
  const progress = useProgress();
  const pct = percentComplete(progress);
  const muted = useMuted();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b-2 border-border bg-card/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-2.5">
        <Link to="/" className="flex items-center gap-2" onClick={() => setOpen(false)}>
          <span className="grid size-10 place-items-center rounded-xl bg-sunny text-xl shadow-chunky-sunny" aria-hidden>
            🎯
          </span>
          <span className="font-display text-lg font-extrabold leading-none text-primary-deep">
            JOM HANTAR
            <br />
            <span className="text-primary">TEPAT!</span>
          </span>
        </Link>

        <nav aria-label="Menu halaman" className="ml-auto hidden items-center gap-1 lg:flex">
          {PAGES.map((p, i) => {
            const done = isStepComplete(progress, p.path);
            return (
              <Link
                key={p.path}
                to={p.path}
                className={cn(
                  "flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 font-display text-sm font-semibold transition-colors",
                  i === current ? "bg-primary text-primary-foreground" : "text-foreground hover:bg-secondary",
                )}
              >
                <span
                  className={cn(
                    "grid size-5 place-items-center rounded-full text-[11px] font-bold",
                    done ? "bg-success text-success-foreground" : i === current ? "bg-primary-foreground/25" : "bg-secondary",
                  )}
                >
                  {done ? "✓" : p.no}
                </span>
                {p.short}
              </Link>
            );
          })}
          <Link
            to="/profil-pembangun"
            className={cn(
              "flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 font-display text-sm font-semibold transition-colors",
              pathname === "/profil-pembangun" ? "bg-primary text-primary-foreground" : "text-foreground hover:bg-secondary",
            )}
          >
            <UserRound className="size-4" aria-hidden />
            Profil
          </Link>
        </nav>

        <div className="ml-auto flex items-center gap-2 lg:ml-2">
          <button
            type="button"
            onClick={() => setMuted(!muted)}
            className="grid size-10 place-items-center rounded-xl border-2 border-border bg-card text-primary hover:bg-secondary"
            aria-label={muted ? "Hidupkan bunyi" : "Matikan bunyi"}
            title={muted ? "Hidupkan bunyi" : "Matikan bunyi"}
          >
            {muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
          </button>
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            className="grid size-10 place-items-center rounded-xl border-2 border-border bg-card text-primary hover:bg-secondary lg:hidden"
            aria-label="Buka menu"
            aria-expanded={open}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </div>

      <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 pb-2">
        <span className="shrink-0 text-xs font-bold text-muted-foreground">Kemajuan saya</span>
        <div className="flex flex-1 gap-1" aria-hidden>
          {PAGES.map((p) => (
            <span
              key={p.path}
              className={cn(
                "h-2.5 flex-1 rounded-full transition-colors",
                isStepComplete(progress, p.path) ? "bg-success" : "bg-secondary",
              )}
            />
          ))}
        </div>
        <span className="shrink-0 font-display text-sm font-bold text-primary" aria-label={`Kemajuan ${pct} peratus`}>
          {pct}%
        </span>
      </div>

      {open && (
        <nav aria-label="Menu halaman (mudah alih)" className="border-t-2 border-border bg-card px-4 py-3 lg:hidden">
          <ul className="grid gap-2 sm:grid-cols-2">
            {PAGES.map((p, i) => (
              <li key={p.path}>
                <Link
                  to={p.path}
                  onClick={() => setOpen(false)}
                  className={cn(
                    "flex items-center gap-3 rounded-xl px-3 py-2.5 font-display font-semibold",
                    i === current ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground",
                  )}
                >
                  <span aria-hidden>{p.emoji}</span>
                  {p.no}. {p.title}
                  {isStepComplete(progress, p.path) && <span className="ml-auto">✓</span>}
                </Link>
              </li>
            ))}
            <li>
              <Link
                to="/profil-pembangun"
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center gap-3 rounded-xl px-3 py-2.5 font-display font-semibold",
                  pathname === "/profil-pembangun" ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground",
                )}
              >
                <UserRound className="size-5" aria-hidden />
                Profil Pembangun
              </Link>
            </li>
          </ul>
        </nav>
      )}
    </header>
  );
}
