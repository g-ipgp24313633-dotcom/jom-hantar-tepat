import { parseVideoUrl } from "@/config/media";

/** Simple embed for the concept video; shows a clear notice when no real video has been added. */
export function VideoSlot({ url, title }: { url: string; title: string }) {
  const src = parseVideoUrl(url);
  if (src.kind === "youtube") {
    return (
      <div className="aspect-video overflow-hidden rounded-2xl bg-foreground">
        <iframe
          className="size-full"
          src={`https://www.youtube-nocookie.com/embed/${src.id}`}
          title={title}
          allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      </div>
    );
  }
  if (src.kind === "file") {
    return <video className="aspect-video w-full rounded-2xl bg-foreground" src={src.url} controls preload="metadata" />;
  }
  return (
    <div className="grid aspect-video place-items-center rounded-2xl border-4 border-dashed border-sky-strong bg-secondary p-6 text-center">
      <div>
        <p className="text-5xl" aria-hidden>🎬</p>
        <p className="mt-2 font-display text-xl font-bold text-primary-deep">Video penerangan belum dimasukkan</p>
        <p className="mx-auto mt-1 max-w-md text-muted-foreground">
          Guru boleh menambah video sebenar dalam fail tetapan video (CONCEPT_VIDEO_URL). Sementara itu, baca kad dan
          langkah di halaman ini.
        </p>
      </div>
    </div>
  );
}
