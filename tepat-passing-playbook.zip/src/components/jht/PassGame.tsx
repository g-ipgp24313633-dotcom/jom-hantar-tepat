import React, { useEffect, useRef, useState, type PointerEvent } from "react";
import { Button } from "@/components/ui/button";
import { Confetti } from "@/components/jht/Confetti";
import { ATTEMPTS_PER_LEVEL, BALL_START, FIELD_H, FIELD_W, LEVELS, MAX_TOTAL, computeShot, feedback, isHit, pointsFor, targetFor, type LevelId, type Point } from "@/lib/game";
import { markDone, recordBest } from "@/lib/progress";
import { play, setMuted, useMuted } from "@/lib/sound";
import { cn } from "@/lib/utils";

export function PassGame() {
  const svgRef = useRef<SVGSVGElement>(null);
  const [level, setLevel] = useState<LevelId>(1);
  const [target, setTarget] = useState<Point>(() => ({ x: 200, y: LEVELS[1].targetY }));
  const [tries, setTries] = useState(0);
  const [score, setScore] = useState(0);
  const [hits, setHits] = useState(0);
  const [aim, setAim] = useState<Point | null>(null);
  const [ball, setBall] = useState<Point>(BALL_START);
  const [flying, setFlying] = useState(false);
  const [msg, setMsg] = useState("Tarik bola ke belakang, kemudian lepaskan untuk menghantar!");
  const [done, setDone] = useState(false);
  const [levelDone, setLevelDone] = useState(false);
  const [kAim, setKAim] = useState({ angle: 0, power: 0.6 });
  const muted = useMuted();
  const L = LEVELS[level];

  const toField = (e: PointerEvent): Point => {
    const r = svgRef.current!.getBoundingClientRect();
    return { x: ((e.clientX - r.left) / r.width) * FIELD_W, y: ((e.clientY - r.top) / r.height) * FIELD_H };
  };

  const release = (p: Point | null = aim) => {
    if (!p || levelDone) return;
    const shot = computeShot(BALL_START, p);
    setAim(null);
    if (!shot) return;
    play("throw");
    setFlying(true);
    setBall(shot.landing);
    const hit = isHit(shot.landing, target, L.radius);
    setTimeout(() => {
      play(hit ? "hit" : "miss");
      const newScore = score + pointsFor(level, hit);
      const n = tries + 1;
      setScore(newScore);
      if (hit) setHits((h) => h + 1);
      setMsg(feedback(shot.landing, target, L.radius, hit, hits));
      setTimeout(() => {
        setFlying(false);
        setBall(BALL_START);
        if (n >= ATTEMPTS_PER_LEVEL) {
          if (level < 3) {
            setTries(n);
            setLevelDone(true);
            setMsg(`${L.name} selesai! Tekan Tahap Seterusnya. 🎉`);
          } else {
            setTries(n);
            setDone(true);
            recordBest("cabaran", newScore);
            markDone("cabaran");
            play("win");
          }
        } else {
          setTries(n);
          setTarget(targetFor(level));
        }
      }, 900);
    }, 550);
  };

  const nextLevel = () => {
    const nl = (level + 1) as LevelId;
    setLevel(nl); setTries(0); setLevelDone(false); setTarget(targetFor(nl));
    setMsg(`${LEVELS[nl].name}: ${LEVELS[nl].label}!`);
  };

  // Keyboard alternative: arrows aim/power, Space/Enter throws.
  const kPoint = (): Point => {
    const len = kAim.power * 160;
    return { x: BALL_START.x - Math.sin(kAim.angle) * len, y: BALL_START.y + Math.cos(kAim.angle) * len };
  };
  useEffect(() => {
    if (!keyMode) return;
    setAim(kPoint());
  }, [kAim]);

  const restart = () => {
    setLevelDone(false);
    setLevel(1); setTries(0); setScore(0); setHits(0); setDone(false);
    setTarget({ x: 200, y: LEVELS[1].targetY });
    setMsg("Tarik bola ke belakang, kemudian lepaskan untuk menghantar!");
  };

  const [keyMode, setKeyMode] = useState(false);
  const onKey = (e: React.KeyboardEvent) => {
    if (flying || done || levelDone) return;
    const k = e.key;
    if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", " ", "Enter"].includes(k)) e.preventDefault(); else return;
    setKeyMode(true);
    if (k === "ArrowLeft") setKAim((a) => ({ ...a, angle: Math.max(-1, a.angle - 0.05) }));
    if (k === "ArrowRight") setKAim((a) => ({ ...a, angle: Math.min(1, a.angle + 0.05) }));
    if (k === "ArrowUp") setKAim((a) => ({ ...a, power: Math.min(1, a.power + 0.05) }));
    if (k === "ArrowDown") setKAim((a) => ({ ...a, power: Math.max(0.1, a.power - 0.05) }));
    if (k === " " || k === "Enter") release(kPoint());
  };
  const preview = aim ? computeShot(BALL_START, aim) : null;

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
      <div className="card-fun relative overflow-hidden p-3">
        {done && <Confetti />}
        <svg
          ref={svgRef}
          viewBox={`0 0 ${FIELD_W} ${FIELD_H}`}
          className="mx-auto block max-h-[70vh] w-full touch-none select-none rounded-xl bg-mint outline-none focus-visible:ring-4 focus-visible:ring-primary"
          onPointerDown={(e) => { if (flying || done) return; (e.target as Element).setPointerCapture?.(e.pointerId); setAim(toField(e)); }}
          onPointerMove={(e) => aim && setAim(toField(e))}
          onPointerUp={() => release()}
          tabIndex={0}
          onKeyDown={onKey}
          onFocus={() => setKeyMode(true)}
          onBlur={() => { setKeyMode(false); setAim(null); }}
          role="img"
          aria-label="Padang permainan. Tarik bola ke belakang dan lepaskan untuk menghantar ke sasaran."
        >
          {[390, 250, 115].map((y, i) => (
            <line key={y} x1="0" x2={FIELD_W} y1={y + 60} y2={y + 60} className="stroke-card" strokeDasharray="8 8" strokeWidth="2" opacity={0.6 - i * 0.1} />
          ))}
          <circle cx={target.x} cy={target.y} r={L.radius} className="fill-coral" />
          <circle cx={target.x} cy={target.y} r={L.radius * 0.66} className="fill-card" />
          <circle cx={target.x} cy={target.y} r={L.radius * 0.33} className="fill-coral" />
          {preview && (
            <line x1={BALL_START.x} y1={BALL_START.y} x2={preview.landing.x} y2={preview.landing.y} className="stroke-primary-deep" strokeWidth="3" strokeDasharray="6 6" />
          )}
          <circle
            cx={ball.x}
            cy={ball.y}
            r={18}
            className="fill-sunny stroke-primary-deep"
            strokeWidth="3"
            style={{ transition: flying ? "cx 0.5s ease-out, cy 0.5s ease-out" : "none" }}
          />
        </svg>
      </div>
      <aside className="flex flex-col gap-3">
        <div className="card-fun p-4">
          <p className="font-display text-xl font-bold text-primary-deep">{L.name} · {L.zone}</p>
          <p className="text-muted-foreground">{L.label} — {L.points} mata setiap kena</p>
          <div className="mt-3 grid grid-cols-2 gap-2 text-center">
            <div className="rounded-xl bg-sunny p-2"><p className="text-sm">Markah</p><p className="font-display text-2xl font-bold">{score}/{MAX_TOTAL}</p></div>
            <div className="rounded-xl bg-secondary p-2"><p className="text-sm">Cubaan</p><p className="font-display text-2xl font-bold">{Math.min(tries + (done ? 0 : 1), ATTEMPTS_PER_LEVEL)}/{ATTEMPTS_PER_LEVEL}</p></div>
          </div>
        </div>
        <div className={cn("animate-pop rounded-2xl p-4 text-lg font-semibold", done ? "bg-mint" : "bg-card shadow-card")} key={msg}>
          {done ? `Tahniah! Kamu kena ${hits} sasaran dan dapat ${score} mata! 🏆` : msg}
        </div>
        <div className="flex flex-wrap gap-2">
          {levelDone && <Button variant="mint" size="big" onClick={nextLevel}>Tahap Seterusnya ➜</Button>}
          <Button variant="game" size="big" onClick={restart}>MAIN SEMULA</Button>
          <Button variant="soft" size="big" onClick={() => setMuted(!muted)}>{muted ? "🔇 Bunyi Mati" : "🔊 Bunyi Hidup"}</Button>
        </div>
        <p className="text-sm text-muted-foreground">Papan kekunci: tekan padang, guna ← → untuk arah, ↑ ↓ untuk kekuatan, Space untuk hantar.</p>
      </aside>
    </div>
  );
}
