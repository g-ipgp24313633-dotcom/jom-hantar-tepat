import { useState } from "react";
import { Button } from "@/components/ui/button";

const TYPES = [
  { id: "dada", label: "Hantaran Dada", path: "M70 110 Q200 100 330 110" },
  { id: "lantun", label: "Hantaran Lantun", path: "M70 110 L200 165 L330 110" },
  { id: "atas", label: "Hantaran Atas Kepala", path: "M70 80 Q200 -10 330 80" },
] as const;

function Player({ x, flip }: { x: number; flip?: boolean }) {
  return (
    <g transform={`translate(${x} 0) ${flip ? "scale(-1 1)" : ""}`} className="text-primary-deep">
      <circle cx="0" cy="60" r="14" fill="currentColor" />
      <line x1="0" y1="74" x2="0" y2="130" stroke="currentColor" strokeWidth="8" strokeLinecap="round" />
      <line x1="0" y1="90" x2="22" y2="105" stroke="currentColor" strokeWidth="7" strokeLinecap="round" className="pa-arm" />
      <line x1="0" y1="130" x2="-14" y2="168" stroke="currentColor" strokeWidth="7" strokeLinecap="round" />
      <line x1="0" y1="130" x2="16" y2="168" stroke="currentColor" strokeWidth="7" strokeLinecap="round" />
    </g>
  );
}

export function PassAnimation() {
  const [t, setT] = useState(0);
  const cur = TYPES[t]!;
  return (
    <div>
      <div className="mb-3 flex flex-wrap gap-2">
        {TYPES.map((ty, i) => (
          <Button key={ty.id} variant={i === t ? "game" : "soft"} onClick={() => setT(i)}>{ty.label}</Button>
        ))}
      </div>
      <svg viewBox="0 0 400 190" className="w-full rounded-2xl bg-sky-fade" role="img" aria-label={`Animasi ${cur.label}`}>
        <rect x="0" y="168" width="400" height="22" className="fill-mint" />
        <path d={cur.path} fill="none" stroke="currentColor" strokeDasharray="6 6" className="text-primary/40" strokeWidth="2" />
        <Player x={50} />
        <Player x={350} flip />
        <circle r="11" className="fill-accent stroke-primary-deep" strokeWidth="2" key={cur.id}>
          <animateMotion dur="1.8s" repeatCount="indefinite" path={cur.path} keyPoints="0;1;0" keyTimes="0;0.5;1" calcMode="linear" />
        </circle>
      </svg>
      <p className="mt-2 text-center text-sm font-bold text-primary">Bola bergerak antara dua rakan — perhatikan laluannya!</p>
    </div>
  );
}
