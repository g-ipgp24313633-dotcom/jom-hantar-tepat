import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Confetti } from "@/components/jht/Confetti";
import { QUIZ, quizResult, shuffle } from "@/lib/quiz";
import { markDone, recordBest } from "@/lib/progress";
import { play } from "@/lib/sound";
import { cn } from "@/lib/utils";

export function QuizGame() {
  const [qs, setQs] = useState(QUIZ);
  const [i, setI] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const q = qs[i]!;

  const choose = (k: number) => {
    if (picked !== null) return;
    setPicked(k);
    const ok = k === q.answer;
    if (ok) setScore((s) => s + 1);
    play(ok ? "correct" : "wrong");
  };
  const next = () => {
    if (i + 1 >= qs.length) {
      setDone(true); recordBest("kuiz", score); markDone("kuiz"); play("win"); return;
    }
    setI(i + 1); setPicked(null);
  };
  const restart = () => { setQs(shuffle(QUIZ)); setI(0); setPicked(null); setScore(0); setDone(false); };

  if (done) {
    const r = quizResult(score, qs.length);
    return (
      <div className="card-fun relative animate-pop overflow-hidden p-8 text-center">
        <Confetti />
        <p className="text-7xl" aria-hidden>{r.badge}</p>
        <p className="mt-2 font-display text-3xl font-extrabold text-primary-deep">{r.title}</p>
        <p className="mt-1 text-2xl font-bold">Skor: {score}/{qs.length}</p>
        <p className="mt-2 text-lg text-muted-foreground">{r.msg}</p>
        <Button className="mt-5" variant="game" size="big" onClick={restart}>CUBA LAGI</Button>
      </div>
    );
  }

  return (
    <div className="card-fun p-5">
      <div className="mb-2 flex justify-between text-sm font-bold">
        <span>Soalan {i + 1}/{qs.length} · {q.topic}</span><span>Skor: {score}</span>
      </div>
      <div className="h-3 overflow-hidden rounded-full bg-secondary">
        <div className="h-full bg-primary transition-all" style={{ width: `${((i + (picked !== null ? 1 : 0)) / qs.length) * 100}%` }} />
      </div>
      <p className="mt-4 font-display text-2xl font-bold text-primary-deep">{q.question}</p>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {q.options.map((o, k) => {
          const st = picked === null ? "idle" : k === q.answer ? "right" : k === picked ? "wrong" : "idle";
          return (
            <button key={k} type="button" disabled={picked !== null} onClick={() => choose(k)}
              className={cn("rounded-2xl border-4 bg-card p-4 text-left text-lg font-semibold transition-all",
                st === "right" && "border-success bg-mint", st === "wrong" && "animate-wiggle border-coral bg-coral-soft",
                st === "idle" && "border-border hover:border-primary")}>
              <span className="mr-2 font-display font-bold">{String.fromCharCode(65 + k)}.</span>{o}
            </button>
          );
        })}
      </div>
      {picked !== null && (
        <div className={cn("animate-pop mt-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl p-4", picked === q.answer ? "bg-mint" : "bg-coral-soft")}>
          <p className="text-lg"><strong>{picked === q.answer ? "Betul! 🎉 " : "Belum tepat. "}</strong>{q.explain}</p>
          <Button variant="game" size="big" onClick={next}>{i + 1 >= qs.length ? "Lihat Keputusan" : "Seterusnya"}</Button>
        </div>
      )}
    </div>
  );
}
