import { Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Home } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { PAGES, type PagePath } from "@/lib/pages";
import { markVisited } from "@/lib/progress";

type Props = {
  path: PagePath;
  subtitle?: string;
  segment?: string;
  children: ReactNode;
};

/** Common page frame: numbered title band + Kembali / Laman Utama / Seterusnya buttons. */
export function PageShell({ path, subtitle, segment, children }: Props) {
  const idx = PAGES.findIndex((p) => p.path === path);
  const page = PAGES[idx] ?? PAGES[0]!;
  const prev = PAGES[idx - 1];
  const next = PAGES[idx + 1];

  useEffect(() => {
    markVisited(path);
  }, [path]);

  return (
    <main className="bg-sky-fade min-h-[calc(100vh-110px)]">
      <section className="mx-auto max-w-6xl px-4 pt-8 pb-6 sm:pt-10">
        <div className="flex flex-wrap items-center gap-3">
          <span className="grid size-12 place-items-center rounded-2xl bg-primary font-display text-2xl font-extrabold text-primary-foreground shadow-chunky">
            {page.no}
          </span>
          {segment && (
            <span className="rounded-full bg-sunny px-3 py-1 text-sm font-bold text-sunny-foreground">{segment}</span>
          )}
        </div>
        <h1 className="mt-4 font-display text-4xl font-extrabold text-primary-deep sm:text-5xl">
          {page.title} <span aria-hidden>{page.emoji}</span>
        </h1>
        {subtitle && <p className="mt-2 max-w-2xl text-lg text-muted-foreground">{subtitle}</p>}
      </section>

      <div className="mx-auto max-w-6xl px-4 pb-10">{children}</div>

      <nav aria-label="Navigasi halaman" className="mx-auto max-w-6xl px-4 pb-12">
        <div className="card-fun flex flex-wrap items-center justify-between gap-3 p-4">
          {prev ? (
            <Button asChild variant="soft" size="big">
              <Link to={prev.path}>
                <ArrowLeft /> Kembali
              </Link>
            </Button>
          ) : (
            <span />
          )}
          <Button asChild variant="mint" size="big">
            <Link to="/">
              <Home /> Laman Utama
            </Link>
          </Button>
          {next ? (
            <Button asChild variant="game" size="big">
              <Link to={next.path}>
                Seterusnya <ArrowRight />
              </Link>
            </Button>
          ) : (
            <span />
          )}
        </div>
      </nav>
    </main>
  );
}

export function SectionTitle({ icon, children, hint }: { icon: string; children: ReactNode; hint?: string }) {
  return (
    <div className="mb-4 flex items-start gap-3">
      <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-sunny text-2xl" aria-hidden>
        {icon}
      </span>
      <div>
        <h2 className="font-display text-2xl font-bold text-primary-deep sm:text-3xl">{children}</h2>
        {hint && <p className="text-muted-foreground">{hint}</p>}
      </div>
    </div>
  );
}
