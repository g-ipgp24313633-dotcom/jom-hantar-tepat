import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="border-t-2 border-border bg-card">
      <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-6 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
        <p>
          <span className="font-display font-bold text-primary-deep">JOM HANTAR TEPAT!</span> · Pendidikan Jasmani Tahun 5 · SP 1.6.1
        </p>
        <p>
          Tiada log masuk · Tiada data peribadi dikumpul ·{" "}
          <Link to="/refleksi" hash="kredit" className="font-semibold text-primary underline-offset-4 hover:underline">
            Kredit &amp; Sumber
          </Link>{" · "}
          <Link to="/guru" className="font-semibold text-primary underline-offset-4 hover:underline">
            Ruang Guru
          </Link>{" · "}
          <Link to="/profil-pembangun" className="font-semibold text-primary underline-offset-4 hover:underline">
            Profil Pembangun
          </Link>
        </p>
      </div>
    </footer>
  );
}
