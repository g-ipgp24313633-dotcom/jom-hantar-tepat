import { useEffect, useRef, useState } from "react";
import { ArrowRight, CheckCircle2, ExternalLink, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cueTimes, parseVideoUrl, VIDEO_CUES } from "@/config/media";
import { markDone } from "@/lib/progress";
import { cn } from "@/lib/utils";

type Player = {
  getCurrentTime: () => number;
  getDuration: () => number;
  pauseVideo: () => void;
  playVideo: () => void;
  seekTo: (seconds: number, ahead: boolean) => void;
  destroy: () => void;
};
type YouTubeApi = {
  Player: new (element: HTMLElement, options: {
    videoId: string;
    host: string;
    playerVars: Record<string, string | number>;
    events: { onReady: () => void; onError: () => void; onStateChange: (event: { data: number }) => void };
  }) => Player;
};
type YouTubeWindow = Window & { YT?: YouTubeApi; onYouTubeIframeAPIReady?: () => void };
let apiPromise: Promise<YouTubeApi> | undefined;
function loadYouTube(): Promise<YouTubeApi> {
  const target = window as YouTubeWindow;
  if (target.YT?.Player) return Promise.resolve(target.YT);
  if (!apiPromise) {
    apiPromise = new Promise((resolve, reject) => {
      const previous = target.onYouTubeIframeAPIReady;
      target.onYouTubeIframeAPIReady = () => {
        previous?.();
        if (target.YT?.Player) resolve(target.YT);
      };
      const script = document.createElement("script");
      script.src = "https://www.youtube.com/iframe_api";
      script.onerror = () => { apiPromise = undefined; reject(new Error("Video unavailable")); };
      document.head.appendChild(script);
    });
  }
  return apiPromise;
}

export function InteractiveVideo({ url }: { url: string }) {
  const source = parseVideoUrl(url);
  const container = useRef<HTMLDivElement>(null);
  const player = useRef<Player | null>(null);
  const file = useRef<HTMLVideoElement>(null);
  const answered = useRef(0);
  const active = useRef<number | null>(null);
  const [question, setQuestion] = useState<number | null>(null);
  const [choice, setChoice] = useState<number | null>(null);
  const [results, setResults] = useState<boolean[]>([]);
  const [complete, setComplete] = useState(false);
  const [error, setError] = useState(false);
  const [now, setNow] = useState(0);
  const [duration, setDuration] = useState(0);
  const correct = results.filter(Boolean).length;
  const markah = correct * 10;
  const peratus = Math.round((correct / VIDEO_CUES.length) * 100);

  function openQuestion(index: number) {
    if (active.current !== null || index >= VIDEO_CUES.length) return;
    active.current = index;
    player.current?.pauseVideo?.();
    file.current?.pause();
    setChoice(null);
    setQuestion(index);
  }

  useEffect(() => {
    if (source.kind !== "youtube" || !container.current) return;
    let disposed = false;
    let ready = false;
    let instance: Player | null = null;
    const mount = document.createElement("div");
    container.current.replaceChildren(mount);
    const timeout = window.setTimeout(() => { if (!disposed) setError(true); }, 15000);
    loadYouTube().then((api) => {
      if (disposed) return;
      instance = new api.Player(mount, {
        videoId: source.id,
        host: "https://www.youtube-nocookie.com",
        playerVars: { playsinline: 1, origin: window.location.origin, rel: 0 },
        events: {
          onReady: () => { ready = true; window.clearTimeout(timeout); if (!disposed) setError(false); },
          onError: () => { if (!disposed) setError(true); },
          onStateChange: ({ data }) => {
            if (data === 1 && active.current !== null) instance?.pauseVideo();
            if (data === 0 && answered.current < VIDEO_CUES.length) openQuestion(answered.current);
          },
        },
      });
      player.current = instance;
    }).catch(() => { if (!disposed) setError(true); });
    const interval = window.setInterval(() => {
      if (!ready || !instance) return;
      const d = instance.getDuration?.() ?? 0;
      setNow(instance.getCurrentTime?.() ?? 0);
      setDuration(d);
      if (active.current !== null || answered.current >= VIDEO_CUES.length) return;
      const times = cueTimes(VIDEO_CUES, d);
      const at = times[answered.current];
      if (at !== undefined && instance.getCurrentTime() >= at) openQuestion(answered.current);
    }, 300);
    return () => {
      disposed = true;
      window.clearInterval(interval);
      window.clearTimeout(timeout);
      instance?.destroy();
      player.current = null;
    };
  }, [url]);

  function continueVideo() {
    const cue = question === null ? undefined : VIDEO_CUES[question];
    if (!cue || choice === null) return;
    const next = [...results, choice === cue.answer];
    setResults(next);
    answered.current = next.length;
    active.current = null;
    setQuestion(null);
    setChoice(null);
    if (next.length === VIDEO_CUES.length) {
      setComplete(true);
      markDone("video");
    }
    player.current?.playVideo?.();
    void file.current?.play().catch(() => {});
  }

  function restart() {
    answered.current = 0;
    active.current = null;
    setQuestion(null);
    setChoice(null);
    setResults([]);
    setComplete(false);
    setNow(0);
    player.current?.seekTo?.(0, true);
    player.current?.playVideo?.();
    if (file.current) { file.current.currentTime = 0; void file.current.play().catch(() => {}); }
  }

  const cue = question === null ? undefined : VIDEO_CUES[question];
  return (
    <section aria-label="Aktiviti video hantaran" className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-display text-2xl font-bold text-primary-deep">Misi Hantaran Tepat</h2>
        <span className="font-bold text-primary">{results.length} / {VIDEO_CUES.length} soalan selesai</span>
      </div>
      <div className="grid grid-cols-3 gap-3 text-center" aria-label="Papan skor">
        <div className="card-fun p-3"><p className="text-sm font-bold text-primary">Markah</p><p className="font-display text-3xl font-bold text-primary-deep" data-testid="markah">{markah} / {VIDEO_CUES.length * 10}</p></div>
        <div className="card-fun p-3"><p className="text-sm font-bold text-primary">Betul</p><p className="font-display text-3xl font-bold text-primary-deep">{correct} / {VIDEO_CUES.length}</p></div>
        <div className="card-fun p-3"><p className="text-sm font-bold text-primary">Skor</p><p className="font-display text-3xl font-bold text-primary-deep" data-testid="skor">{peratus}%</p></div>
      </div>
      <div className="aspect-video overflow-hidden rounded-2xl bg-foreground [&_iframe]:size-full">
        {source.kind === "youtube" && <div ref={container} className="size-full" />}
        {source.kind === "file" && <video ref={file} src={source.url} controls playsInline className="size-full" onError={() => setError(true)} onTimeUpdate={(event) => {
          const video = event.currentTarget;
          setNow(video.currentTime); setDuration(video.duration || 0);
          const at = cueTimes(VIDEO_CUES, video.duration)[answered.current];
          if (at !== undefined && video.currentTime >= at) openQuestion(answered.current);
        }} onPlay={() => { if (active.current !== null) file.current?.pause(); }} onEnded={() => openQuestion(answered.current)} />}
      </div>
      {source.kind !== "none" && (() => {
        const times = duration > 0 ? cueTimes(VIDEO_CUES, duration) : [];
        const fmt = (t: number) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, "0")}`;
        return <div aria-label="Garis masa video">
          <div className="relative h-3 rounded-full bg-secondary">
            <div className="h-full rounded-full bg-primary transition-all" style={{ width: duration ? `${Math.min(100, (now / duration) * 100)}%` : "0%" }} />
            {times.map((t, i) => <span key={i} title={`Soalan ${i + 1}`} className={cn("absolute top-1/2 size-5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-card", i < results.length ? "bg-mint-foreground" : "bg-accent")} style={{ left: `${(t / duration) * 100}%` }} />)}
          </div>
          <p className="mt-1 text-sm font-bold text-primary">{fmt(now)} / {duration ? fmt(duration) : "--:--"} · Video akan berhenti sendiri pada setiap titik kuning untuk soalan.</p>
        </div>;
      })()}
      {error && <p role="alert" className="rounded-xl bg-sunny p-4 text-sunny-foreground">Video tidak dapat dimuatkan di sini. Buka di YouTube dan jawab soalan di bawah.</p>}
      <div className="flex flex-wrap items-center gap-3">
        <Button asChild variant="soft"><a href={url} target="_blank" rel="noopener noreferrer"><ExternalLink /> Buka di YouTube</a></Button>
        {!complete && !cue && (error || source.kind === "none") && <Button variant="sunny" onClick={() => openQuestion(answered.current)}>Soalan seterusnya <ArrowRight /></Button>}
        <Button variant="soft" size="icon" aria-label="Ulang aktiviti" title="Ulang aktiviti" onClick={restart}><RotateCcw /></Button>
      </div>
      <div className="grid grid-cols-3 gap-2" aria-label="Kemajuan soalan">
        {VIDEO_CUES.map((_, index) => <div key={index} className={cn("rounded-lg px-2 py-3 text-center font-bold", index < results.length ? "bg-mint text-mint-foreground" : index === question ? "bg-sunny text-sunny-foreground" : "bg-secondary text-secondary-foreground")}>Soalan {index + 1}{index < results.length && <CheckCircle2 className="mx-auto mt-1 size-4" />}</div>)}
      </div>
      {cue && <section aria-label={`Soalan ${Number(question) + 1}`} className="border-t-2 border-border pt-5" aria-live="polite">
        <p className="font-bold text-primary">Soalan {Number(question) + 1} daripada 3</p>
        <h3 className="mt-2 font-display text-2xl font-bold text-primary-deep">{cue.question}</h3>
        <div className="mt-4 grid gap-3">
          {cue.options.map((option, index) => <Button key={option} variant="soft" disabled={choice !== null} onClick={() => setChoice(index)} className={cn("h-auto min-h-14 justify-start whitespace-normal p-4 text-left text-base", choice !== null && index === cue.answer && "border-mint-foreground bg-mint", choice === index && index !== cue.answer && "border-destructive bg-coral-soft")}><span className="shrink-0 font-bold">{String.fromCharCode(65 + index)}.</span>{option}</Button>)}
        </div>
        {choice !== null && <div role="status" className="mt-4 rounded-xl bg-secondary p-4">
          <p className="font-display text-xl font-bold">{choice === cue.answer ? "Syabas! Jawapan betul!" : "Belum tepat. Jom belajar bersama!"}</p>
          <p className="mt-2">{cue.explain}</p>
          <Button variant="game" className="mt-4" onClick={continueVideo}>{results.length === 2 ? "Selesaikan aktiviti" : "Sambung video"}<ArrowRight /></Button>
        </div>}
      </section>}
      {complete && <div role="status" className="border-t-2 border-border pt-5 text-center">
        <CheckCircle2 className="mx-auto size-10 text-mint-foreground" />
        <h3 className="mt-2 font-display text-2xl font-bold text-primary-deep">Misi selesai!</h3>
        <p className="mt-2 text-lg">{correct} daripada 3 jawapan betul.</p>
        <p className="mt-1 font-display text-2xl font-bold text-primary">Markah: {markah} / {VIDEO_CUES.length * 10} · Skor: {peratus}%</p>
        <Button variant="mint" className="mt-4" onClick={restart}><RotateCcw /> Cuba lagi</Button>
      </div>}
    </section>
  );
}