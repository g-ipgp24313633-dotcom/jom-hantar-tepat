import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Confetti } from "@/components/jht/Confetti";
import { Textarea } from "@/components/ui/textarea";
import { markDone } from "@/lib/progress";
import { play } from "@/lib/sound";
import { cn } from "@/lib/utils";

const LEVELS = [
  { e: "🤩", t: "Sangat faham" },
  { e: "🙂", t: "Faham" },
  { e: "🤔", t: "Kurang faham" },
];
const QS = [
  "Apakah kemahiran yang kamu pelajari hari ini?",
  "Bagaimanakah kamu boleh meningkatkan ketepatan hantaran?",
  "Adakah kamu seronok belajar hari ini? Mengapa?",
];

export function Reflection() {
  const [lvl, setLvl] = useState<number | null>(null);
  const [ans, setAns] = useState(["", "", ""]);
  const [sent, setSent] = useState(false);
  const ready = lvl !== null && ans.every((a) => a.trim());

  if (sent) {
    return (
      <div className="card-fun relative animate-pop overflow-hidden p-8 text-center">
        <Confetti />
        <p className="text-7xl" aria-hidden>🏅</p>
        <p className="mt-2 font-display text-3xl font-extrabold text-primary-deep">Tahniah, Juara Hantaran!</p>
        <p className="mt-2 text-lg">Kamu telah melengkapkan semua aktiviti. Teruskan berlatih: lihat sasaran, langkah ke hadapan dan ikut lajak!</p>
        <div className="mt-5 flex flex-wrap justify-center gap-2"><Button variant="soft" size="big" onClick={() => setSent(false)}>Ubah Jawapan</Button><Button asChild variant="game" size="big"><Link to="/">🏠 Kembali ke Laman Utama</Link></Button></div>
      </div>
    );
  }

  return (
    <div className="grid gap-5">
      <div className="card-fun p-5">
        <h2 className="font-display text-2xl font-bold text-primary-deep">Rumusan Pelajaran 📝</h2>
        <ul className="mt-2 list-disc space-y-1 pl-6 text-lg">
          <li>Hantaran ialah memindahkan bola kepada rakan atau sasaran dengan tepat.</li>
          <li>Pegang bola dengan betul, mata lihat sasaran, kaki melangkah ke hadapan.</li>
          <li>Tolak bola dan tangan ikut lajak ke arah sasaran.</li>
          <li>Pastikan rakan bersedia supaya hantaran selamat.</li>
        </ul>
      </div>
      <div className="card-fun p-5">
        <p className="font-display text-xl font-bold text-primary-deep">Tahap kefahaman saya:</p>
        <div className="mt-3 flex flex-wrap gap-3">
          {LEVELS.map((l, k) => (
            <button key={k} type="button" onClick={() => { setLvl(k); play("click"); }} aria-pressed={lvl === k}
              className={cn("rounded-2xl border-4 bg-card px-5 py-3 text-center transition-all", lvl === k ? "border-primary bg-sunny" : "border-border hover:border-primary")}>
              <span className="block text-5xl" aria-hidden>{l.e}</span><span className="font-bold">{l.t}</span>
            </button>
          ))}
        </div>
      </div>
      {QS.map((q, k) => (
        <label key={q} className="card-fun block p-5">
          <span className="font-display text-xl font-bold text-primary-deep">{k + 1}. {q}</span>
          <Textarea className="mt-2 text-lg" rows={2} maxLength={300} value={ans[k]} placeholder="Tulis jawapan ringkas..."
            onChange={(e) => setAns(ans.map((a, j) => (j === k ? e.target.value : a)))} />
        </label>
      ))}
      <Button variant="game" size="big" disabled={!ready} onClick={() => { setSent(true); markDone("refleksi"); play("win"); }}>
        Hantar Refleksi
      </Button>
    </div>
  );
}
