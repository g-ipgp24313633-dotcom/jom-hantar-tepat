import { useEffect, useRef, useState, type ChangeEvent } from "react";
import {
  BookOpen,
  CalendarRange,
  Camera,
  Dumbbell,
  Eye,
  EyeOff,
  GraduationCap,
  Lightbulb,
  MonitorPlay,
  School,
  ShieldCheck,
  UserRound,
  UsersRound,
} from "lucide-react";
import defaultPhoto from "@/assets/veronika-alexsia.jpg.asset.json";
import { Button } from "@/components/ui/button";

const IC_NUMBER = "060102-13-0258";
const CANDIDATE_NUMBER = "2025312440239";
const PHOTO_STORAGE_KEY = "jht-profil-pembangun-photo";

const identityCards = [
  { label: "Kumpulan", value: "PJ2824", icon: UsersRound, color: "bg-sky/55" },
  { label: "Pengkhususan", value: "Pendidikan Jasmani", icon: GraduationCap, color: "bg-sunny/45" },
  {
    label: "Institusi",
    value: "Institut Pendidikan Guru Kampus Tun Abdul Razak",
    icon: School,
    color: "bg-mint/55",
  },
];

const missions = [
  {
    title: "Pembelajaran Kreatif",
    description: "Menghasilkan pembelajaran yang menyeronokkan.",
    icon: Lightbulb,
    color: "bg-sunny/45",
  },
  {
    title: "Teknologi Digital",
    description: "Mengintegrasikan permainan dan kuiz interaktif.",
    icon: MonitorPlay,
    color: "bg-sky/55",
  },
  {
    title: "Pendidikan Jasmani",
    description: "Menggalakkan pembelajaran aktif melalui pergerakan.",
    icon: Dumbbell,
    color: "bg-mint/55",
  },
];

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Gambar tidak dapat dibaca."));
    reader.readAsDataURL(file);
  });
}

async function resizePhoto(file: File): Promise<string> {
  const source = await fileToDataUrl(file);
  const image = await new Promise<HTMLImageElement>((resolve, reject) => {
    const element = new Image();
    element.onload = () => resolve(element);
    element.onerror = () => reject(new Error("Format gambar tidak disokong."));
    element.src = source;
  });
  const canvas = document.createElement("canvas");
  canvas.width = 640;
  canvas.height = 640;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Gambar tidak dapat diproses.");
  const scale = Math.min(640 / image.naturalWidth, 640 / image.naturalHeight);
  const width = image.naturalWidth * scale;
  const height = image.naturalHeight * scale;
  context.drawImage(image, (640 - width) / 2, (640 - height) / 2, width, height);
  return canvas.toDataURL("image/png");
}

export function DeveloperProfile() {
  const root = useRef<HTMLDivElement>(null);
  const [photo, setPhoto] = useState(defaultPhoto.url);
  const [showPrivateNumbers, setShowPrivateNumbers] = useState(false);
  const [photoError, setPhotoError] = useState("");
  const fileInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(PHOTO_STORAGE_KEY);
      if (saved?.startsWith("data:image/")) setPhoto(saved);
    } catch {
      // The supplied profile photo remains available when browser storage is blocked.
    }
  }, []);

  useEffect(() => {
    const elements = Array.from(root.current?.querySelectorAll<HTMLElement>("[data-profile-reveal]") ?? []);
    if (!("IntersectionObserver" in window) || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      elements.forEach((element) => element.classList.add("is-visible"));
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px" },
    );
    elements.forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, []);

  async function changePhoto(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    setPhotoError("");
    if (!/^image\/(jpeg|png|webp)$/.test(file.type)) {
      setPhotoError("Sila pilih gambar JPG, PNG atau WebP.");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setPhotoError("Saiz gambar mesti kurang daripada 8 MB.");
      return;
    }
    try {
      const resized = await resizePhoto(file);
      setPhoto(resized);
      try {
        window.localStorage.setItem(PHOTO_STORAGE_KEY, resized);
      } catch {
        setPhotoError("Gambar baharu dipaparkan, tetapi tidak dapat disimpan dalam pelayar ini.");
      }
    } catch (error) {
      setPhotoError(error instanceof Error ? error.message : "Gambar tidak dapat diproses.");
    }
  }

  return (
    <div ref={root} className="grid gap-8">
      <section
        aria-label="Maklumat pembangun"
        data-profile-reveal
        className="profile-reveal card-fun overflow-hidden border-card/80 bg-card/85 backdrop-blur-xl"
      >
        <div className="h-2 bg-gradient-to-r from-sky-strong via-sunny to-mint-strong" />
        <div className="px-5 py-9 sm:px-8 sm:py-11 lg:px-12">
          <div className="flex flex-col items-center text-center">
            <div className="group relative mt-3 animate-profile-float">
              <span className="absolute -top-5 -left-7 grid size-11 rotate-[-10deg] place-items-center rounded-2xl border-2 border-border bg-card text-primary shadow-card sm:-left-12" aria-hidden>
                <BookOpen className="size-5" />
              </span>
              <span className="absolute top-16 -right-8 grid size-12 rotate-12 place-items-center rounded-2xl border-2 border-border bg-sunny text-sunny-foreground shadow-card sm:-right-14" aria-hidden>
                <Dumbbell className="size-5" />
              </span>
              <span className="absolute -bottom-3 -left-8 grid size-11 rotate-6 place-items-center rounded-2xl border-2 border-border bg-mint text-mint-foreground shadow-card sm:-left-12" aria-hidden>
                <GraduationCap className="size-5" />
              </span>
              <div className="rounded-full bg-gradient-to-br from-sky-strong via-sunny to-mint-strong p-1.5 transition-shadow duration-500 group-hover:shadow-profile-glow">
                <div className="rounded-full bg-card p-1.5">
                  <div className="grid size-52 place-items-center overflow-hidden rounded-full bg-secondary sm:size-60">
                    {photo ? (
                      <img
                        src={photo}
                        alt="Veronika Alexsia Anak Miger"
                        className="size-full rounded-full object-contain transition-transform duration-500 group-hover:scale-[1.02]"
                      />
                    ) : (
                      <UserRound className="size-28 text-primary" strokeWidth={1.4} aria-label="Gambar profil sementara" />
                    )}
                  </div>
                </div>
              </div>
              <span className="absolute right-3 bottom-3 grid size-12 place-items-center rounded-full border-4 border-card bg-primary text-primary-foreground shadow-card" aria-hidden>
                <Camera className="size-5" />
              </span>
            </div>

            <h2 className="mt-8 max-w-2xl font-sans text-3xl font-extrabold tracking-tight text-primary-deep sm:text-4xl">
              Veronika Alexsia Anak Miger
            </h2>
            <p className="mt-3 rounded-full border border-mint-strong/30 bg-mint px-5 py-2 text-sm font-extrabold text-mint-foreground">
              Guru Pelatih Pendidikan Jasmani
            </p>
            <p className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground">
              <CalendarRange className="size-4 text-primary" aria-hidden />
              Ambilan Ogos 2024/Julai 2029
            </p>
            <input
              ref={fileInput}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="sr-only"
              aria-label="Pilih gambar profil baharu"
              onChange={changePhoto}
            />
            <Button variant="soft" size="sm" className="mt-4" onClick={() => fileInput.current?.click()}>
              <Camera /> Ganti gambar
            </Button>
            <p className="mt-2 text-xs text-muted-foreground">JPG, PNG atau WebP · maksimum 8 MB · disimpan dalam pelayar ini.</p>
            {photoError && <p role="alert" className="mt-2 text-sm font-semibold text-destructive">{photoError}</p>}
          </div>

          <div className="mt-10 grid gap-4 lg:grid-cols-3">
            {identityCards.map(({ label, value, icon: Icon, color }) => (
              <article key={label} className={`rounded-2xl border-2 border-border p-5 text-center transition-transform duration-300 hover:-translate-y-1 ${color}`}>
                <span className="mx-auto grid size-11 place-items-center rounded-xl bg-card/80 text-primary shadow-card" aria-hidden>
                  <Icon className="size-5" />
                </span>
                <h3 className="mt-3 text-sm font-bold tracking-wide text-muted-foreground uppercase">{label}</h3>
                <p className="mt-1 font-display text-lg font-bold text-primary-deep">{value}</p>
              </article>
            ))}
          </div>

          <div className="mt-5 rounded-2xl border-2 border-border bg-secondary/55 p-5 sm:p-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-3">
                <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-card text-primary" aria-hidden>
                  <ShieldCheck className="size-5" />
                </span>
                <div>
                  <h3 className="font-display text-xl font-bold text-primary-deep">Maklumat Peribadi</h3>
                  <p className="text-sm text-muted-foreground">Dilindungi daripada paparan awam secara lalai.</p>
                </div>
              </div>
              <Button
                variant="soft"
                size="sm"
                className="shrink-0"
                aria-pressed={showPrivateNumbers}
                onClick={() => setShowPrivateNumbers((visible) => !visible)}
              >
                {showPrivateNumbers ? <EyeOff /> : <Eye />}
                {showPrivateNumbers ? "Sembunyikan nombor peribadi" : "Papar nombor peribadi"}
              </Button>
            </div>
            <dl className="mt-5 grid gap-4 sm:grid-cols-2" aria-live="polite">
              <div className="rounded-xl bg-card/80 p-4">
                <dt className="text-sm font-bold text-muted-foreground">Nombor Kad Pengenalan</dt>
                <dd className="mt-1 font-display text-lg font-bold tracking-wider text-primary-deep">
                  {showPrivateNumbers ? IC_NUMBER : "••••••-••-••••"}
                </dd>
              </div>
              <div className="rounded-xl bg-card/80 p-4">
                <dt className="text-sm font-bold text-muted-foreground">No Angka Giliran</dt>
                <dd className="mt-1 font-display text-lg font-bold tracking-wider text-primary-deep">
                  {showPrivateNumbers ? CANDIDATE_NUMBER : "•••••••••••••"}
                </dd>
              </div>
            </dl>
            <p className="mt-3 text-xs text-muted-foreground">
              Aktifkan kawalan di atas hanya apabila anda memerlukan nombor ini dipaparkan.
            </p>
          </div>
        </div>
      </section>

      <section
        aria-labelledby="tentang-saya"
        data-profile-reveal
        className="profile-reveal relative overflow-hidden rounded-3xl border-2 border-card/80 bg-card/65 p-6 shadow-card backdrop-blur-xl sm:p-9"
      >
        <BookOpen className="absolute -right-5 -bottom-6 size-36 rotate-[-10deg] text-primary/6" aria-hidden />
        <Dumbbell className="absolute top-5 right-7 size-10 rotate-12 text-mint-foreground/20" aria-hidden />
        <div className="relative max-w-4xl">
          <p className="text-sm font-extrabold tracking-[0.18em] text-primary uppercase">Biografi ringkas</p>
          <h2 id="tentang-saya" className="mt-2 font-sans text-2xl font-extrabold tracking-tight text-primary-deep sm:text-3xl">
            SEDIKIT TENTANG SAYA
          </h2>
          <p className="mt-4 text-base leading-relaxed text-foreground sm:text-lg">
            Saya merupakan guru pelatih Pendidikan Jasmani di IPG Kampus Tun Abdul Razak yang membangunkan JOM HANTAR TEPAT! untuk membantu murid Tahun 5 mempelajari kemahiran menghantar bola ke sasaran secara interaktif dan menyeronokkan.
          </p>
        </div>
      </section>

      <section aria-labelledby="misi-saya" className="pt-2">
        <div data-profile-reveal className="profile-reveal mb-5 text-center">
          <p className="text-sm font-extrabold tracking-[0.18em] text-primary uppercase">Prinsip pembangunan</p>
          <h2 id="misi-saya" className="mt-2 font-sans text-3xl font-extrabold tracking-tight text-primary-deep">MISI SAYA</h2>
        </div>
        <div className="grid gap-5 md:grid-cols-3">
          {missions.map(({ title, description, icon: Icon, color }) => (
            <article
              key={title}
              data-profile-reveal
              className={`profile-reveal group rounded-3xl border-2 border-border p-6 shadow-card transition-all duration-300 hover:-translate-y-2 hover:shadow-profile-lift ${color}`}
            >
              <span className="grid size-13 place-items-center rounded-2xl bg-card/85 text-primary shadow-card transition-transform duration-300 group-hover:rotate-3 group-hover:scale-105" aria-hidden>
                <Icon className="size-6" />
              </span>
              <h3 className="mt-5 font-display text-xl font-bold text-primary-deep">{title}</h3>
              <p className="mt-2 leading-relaxed text-muted-foreground">{description}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
