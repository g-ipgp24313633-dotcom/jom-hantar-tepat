/**
 * Kandungan kurikulum lalai (mengikut RPH). Guru boleh menyunting di halaman
 * "Kenali Pembelajaran Kita"; suntingan disimpan dalam pelayar sahaja.
 */
export type Curriculum = {
  subject: string;
  year: string;
  topic: string;
  sk: string;
  sp: string;
  objectives: string[];
  criteria: string[];
  outcome: string;
};

export const DEFAULT_CURRICULUM: Curriculum = {
  subject: "Pendidikan Jasmani",
  year: "Tahun 5",
  topic: "Hantaran Bola ke Sasaran (Permainan Kategori Serangan)",
  sk: "1.6 Melakukan kemahiran asas permainan kategori serangan dengan lakuan yang betul.",
  sp: "1.6.1 Melakukan pelbagai cara hantaran bola ke sasaran dengan menggunakan alatan dan anggota badan yang dibenarkan.",
  objectives: [
    "Mengenal pasti teknik asas menghantar bola.",
    "Memilih teknik hantaran yang sesuai untuk menghantar bola tepat ke sasaran.",
    "Melakukan pelbagai cara hantaran bola ke sasaran dengan lakuan yang betul.",
  ],
  criteria: [
    "Saya boleh menyatakan sekurang-kurangnya dua cara hantaran bola.",
    "Saya boleh menunjukkan lakuan hantaran yang betul: mata melihat sasaran, kaki melangkah ke hadapan dan tangan ikut lajak.",
    "Saya boleh menghantar bola tepat ke sasaran sekurang-kurangnya 3 daripada 5 cubaan.",
  ],
  outcome: "Murid dapat melakukan pelbagai cara hantaran bola ke sasaran dengan lakuan yang betul.",
};
