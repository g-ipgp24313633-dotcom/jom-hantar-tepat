/**
 * TETAPAN VIDEO GURU
 * Tampal pautan video sebenar di sini (YouTube atau fail MP4) untuk dijadikan video lalai.
 * Guru juga boleh menampal pautan terus di halaman Video Interaktif (disimpan dalam pelayar sahaja).
 */
export const DEFAULT_VIDEO_URL = "https://youtu.be/fICWh8jp00k?si=hil5ncwYhJhsTHzI";

/** Video penerangan konsep di halaman Jom Belajar (YouTube atau MP4). Kosongkan jika belum ada. */
export const CONCEPT_VIDEO_URL = "https://youtu.be/fICWh8jp00k?si=hil5ncwYhJhsTHzI";

export type VideoCue = {
  /** Saat video berhenti untuk soalan. Jika video lebih pendek, soalan diagihkan sama rata. */
  at: number;
  question: string;
  options: [string, string, string];
  answer: number;
  explain: string;
};

/** Tiga soalan berdasarkan "Contoh soalan" Segmen 2 RPH. */
export const VIDEO_CUES: VideoCue[] = [
  {
    at: 20,
    question: "Apakah tujuan utama hantaran?",
    options: [
      "Memindahkan bola kepada rakan atau sasaran dengan tepat",
      "Menunjukkan kekuatan tangan",
      "Melambatkan permainan",
    ],
    answer: 0,
    explain: "Hantaran membantu pasukan menggerakkan bola dengan tepat ke arah sasaran.",
  },
  {
    at: 45,
    question: "Apakah perkara penting ketika membuat hantaran?",
    options: [
      "Menutup mata dan baling sekuat hati",
      "Mata melihat sasaran, kaki melangkah ke hadapan dan tangan ikut lajak",
      "Berdiri tegak tanpa bergerak",
    ],
    answer: 1,
    explain: "Fokus mata, langkah kaki dan ikut lajak menjadikan hantaran betul dan tepat.",
  },
  {
    at: 70,
    question: "Mengapakah kita perlu melihat sasaran?",
    options: [
      "Supaya kelihatan bergaya",
      "Supaya bola bergerak lebih perlahan",
      "Supaya hantaran tepat sampai ke sasaran",
    ],
    answer: 2,
    explain: "Mata memandu arah tangan. Lihat sasaran, bola akan mengikut!",
  },
];

export type VideoSource =
  | { kind: "youtube"; id: string }
  | { kind: "file"; url: string }
  | { kind: "none" };

export function parseVideoUrl(raw: string): VideoSource {
  const url = raw.trim();
  if (!url) return { kind: "none" };
  const yt = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/|live\/)|youtu\.be\/)([\w-]{11})/);
  if (yt?.[1]) return { kind: "youtube", id: yt[1] };
  if (/^https?:\/\//i.test(url)) return { kind: "file", url };
  return { kind: "none" };
}

/** Cue times adjusted so all questions fit inside the real video length. */
export function cueTimes(cues: VideoCue[], duration: number): number[] {
  const redistribute = duration > 0 && cues.some((cue) => cue.at >= duration - 1);
  return cues.map((c, i) => redistribute ? (duration * (i + 1)) / (cues.length + 1) : c.at);
}
