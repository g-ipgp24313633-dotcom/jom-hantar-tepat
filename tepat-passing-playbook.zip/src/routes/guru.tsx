import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { analyzeReflections } from "@/lib/analyze.functions";

export const Route = createFileRoute("/guru")({
  head: () => ({
    meta: [
      { title: "Analisis Refleksi Guru | JOM HANTAR TEPAT!" },
      { name: "description", content: "Guru menampal jawapan refleksi murid dan AI mencadangkan keperluan pembelajaran serta tindakan susulan." },
      { property: "og:title", content: "Analisis Refleksi Guru | JOM HANTAR TEPAT!" },
      { property: "og:description", content: "Kenal pasti keperluan pembelajaran murid dengan bantuan AI." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Page,
});

const SAMPLE = `Murid 1: Saya belajar hantaran dada. Saya perlu lihat sasaran. Seronok! (🤩 Sangat faham)
Murid 2: Hantar bola. Tak tahu macam mana nak tepat. (🤔 Kurang faham)
Murid 3: Kaki melangkah dan tangan ikut lajak. Saya akan berlatih lagi. (🙂 Faham)`;

function Md({ text }: { text: string }) {
  return (
    <div className="space-y-2 text-lg">
      {text.split("\n").map((l, i) => {
        const t = l.replace(/\*\*/g, "");
        if (/^#{1,3} /.test(l)) return <h3 key={i} className="mt-4 font-display text-2xl font-bold text-primary-deep">{t.replace(/^#+ /, "")}</h3>;
        if (/^\s*[-*] /.test(l)) return <p key={i} className="pl-5">• {t.replace(/^\s*[-*] /, "")}</p>;
        return t.trim() ? <p key={i}>{t}</p> : null;
      })}
    </div>
  );
}

function Page() {
  const analyze = useServerFn(analyzeReflections);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [out, setOut] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const run = async () => {
    setBusy(true); setErr(null); setOut(null);
    try {
      const r = await analyze({ data: { text } });
      if (r.ok) setOut(r.text); else setErr(r.error);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Ralat berlaku.");
    } finally { setBusy(false); }
  };

  return (
    <main className="bg-sky-fade min-h-[calc(100vh-110px)]">
      <div className="mx-auto max-w-4xl px-4 py-10">
        <h1 className="font-display text-4xl font-extrabold text-primary-deep">Analisis Refleksi (Guru) 🧑‍🏫</h1>
        <p className="mt-2 text-lg text-muted-foreground">Tampal jawapan refleksi murid. AI akan mengenal pasti keperluan pembelajaran dan mencadangkan tindakan susulan.</p>
        <div className="card-fun mt-6 p-5">
          <Textarea rows={10} className="text-base" value={text} onChange={(e) => setText(e.target.value)} placeholder={SAMPLE} maxLength={12000} />
          <div className="mt-3 flex flex-wrap gap-2">
            <Button variant="game" size="big" disabled={busy || text.trim().length < 10} onClick={run}>{busy ? "Sedang menganalisis..." : "Analisis dengan AI"}</Button>
            <Button variant="soft" size="big" onClick={() => setText(SAMPLE)}>Guna Contoh</Button>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">Elakkan nama penuh murid; gunakan nombor atau nama panggilan.</p>
        </div>
        {err && <p className="mt-4 rounded-2xl bg-coral-soft p-4 font-semibold">{err}</p>}
        {out && <div className="card-fun mt-6 p-6"><Md text={out} /></div>}
      </div>
    </main>
  );
}
