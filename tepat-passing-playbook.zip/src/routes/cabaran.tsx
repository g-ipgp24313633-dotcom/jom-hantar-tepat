import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/jht/PageShell";
import { PassGame } from "@/components/jht/PassGame";

export const Route = createFileRoute("/cabaran")({
  head: () => ({
    meta: [
      { title: "Cabaran Hantar Tepat! | JOM HANTAR TEPAT!" },
      { name: "description", content: "Permainan menghantar bola ke sasaran dalam tiga zon." },
      { property: "og:title", content: "Cabaran Hantar Tepat! | JOM HANTAR TEPAT!" },
      { property: "og:description", content: "Permainan menghantar bola ke sasaran dalam tiga zon." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <PageShell path="/cabaran" subtitle="Permainan menghantar bola ke sasaran dalam tiga zon.">
      <PassGame />
    </PageShell>
  );
}
