import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/jht/PageShell";
import { InteractiveVideo } from "@/components/jht/InteractiveVideo";
import { DEFAULT_VIDEO_URL } from "@/config/media";

export const Route = createFileRoute("/video")({
  head: () => ({
    meta: [
      { title: "Video Interaktif | JOM HANTAR TEPAT!" },
      { name: "description", content: "Video pembelajaran dengan soalan yang muncul pada masa tertentu." },
      { property: "og:title", content: "Video Interaktif | JOM HANTAR TEPAT!" },
      { property: "og:description", content: "Video pembelajaran dengan soalan yang muncul pada masa tertentu." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <PageShell path="/video" subtitle="Video pembelajaran dengan soalan yang muncul pada masa tertentu.">
      <InteractiveVideo url={DEFAULT_VIDEO_URL} />
    </PageShell>
  );
}
