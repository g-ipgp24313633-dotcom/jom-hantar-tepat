import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/jht/PageShell";
import { QuizGame } from "@/components/jht/QuizGame";

export const Route = createFileRoute("/kuiz")({
  head: () => ({
    meta: [
      { title: "Kuiz Juara Hantaran | JOM HANTAR TEPAT!" },
      { name: "description", content: "Kuiz 10 soalan tentang kemahiran menghantar bola." },
      { property: "og:title", content: "Kuiz Juara Hantaran | JOM HANTAR TEPAT!" },
      { property: "og:description", content: "Kuiz 10 soalan tentang kemahiran menghantar bola." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <PageShell path="/kuiz" subtitle="Kuiz 10 soalan tentang kemahiran menghantar bola.">
      <QuizGame />
    </PageShell>
  );
}
