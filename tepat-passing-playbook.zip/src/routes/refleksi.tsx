import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/jht/PageShell";
import { Reflection } from "@/components/jht/Reflection";

export const Route = createFileRoute("/refleksi")({
  head: () => ({
    meta: [
      { title: "Refleksi Pembelajaran | JOM HANTAR TEPAT!" },
      { name: "description", content: "Rumusan pelajaran dan refleksi 3-2-1." },
      { property: "og:title", content: "Refleksi Pembelajaran | JOM HANTAR TEPAT!" },
      { property: "og:description", content: "Rumusan pelajaran dan refleksi 3-2-1." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <PageShell path="/refleksi" subtitle="Rumusan pelajaran dan refleksi 3-2-1.">
      <Reflection />
      <section id="kredit" className="card-fun mt-8 p-5">
        <h2 className="font-display text-2xl font-bold text-primary-deep">Kredit &amp; Sumber</h2>
        <ul className="mt-2 list-disc space-y-1 pl-6">
          <li>Ilustrasi teknik hantaran dihasilkan khas untuk laman ini menggunakan penjana imej AI.</li>
          <li>Video pembelajaran: video YouTube yang dipilih oleh guru (hak milik pencipta asal).</li>
          <li>Kandungan berdasarkan DSKP Pendidikan Jasmani Tahun 5, SK 1.6 / SP 1.6.1.</li>
          <li>Bunyi dijana terus oleh pelayar; ikon emoji sistem.</li>
        </ul>
      </section>
    </PageShell>
  );
}
