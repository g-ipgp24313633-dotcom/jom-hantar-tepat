import { createFileRoute } from "@tanstack/react-router";
import { Pencil, RotateCcw, Save, X } from "lucide-react";
import { useEffect, useState } from "react";
import { PageShell, SectionTitle } from "@/components/jht/PageShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { DEFAULT_CURRICULUM, type Curriculum } from "@/config/curriculum";
import { toast } from "sonner";

export const Route = createFileRoute("/pengenalan")({
  head: () => ({
    meta: [
      { title: "Kenali Pembelajaran Kita | JOM HANTAR TEPAT!" },
      { name: "description", content: "Standard kandungan 1.6, standard pembelajaran 1.6.1, objektif dan kriteria kejayaan pelajaran hantaran bola ke sasaran." },
      { property: "og:title", content: "Kenali Pembelajaran Kita | JOM HANTAR TEPAT!" },
      { property: "og:description", content: "SK 1.6, SP 1.6.1, objektif pembelajaran dan kriteria kejayaan Tahun 5." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Pengenalan,
});

const KEY = "jht-curriculum-v1";

function Pengenalan() {
  const [cur, setCur] = useState<Curriculum>(DEFAULT_CURRICULUM);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<Curriculum>(DEFAULT_CURRICULUM);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setCur({ ...DEFAULT_CURRICULUM, ...JSON.parse(raw) });
    } catch {
      /* ignore */
    }
  }, []);

  const startEdit = () => {
    setDraft(cur);
    setEditing(true);
  };
  const saveEdit = () => {
    const clean: Curriculum = {
      ...draft,
      objectives: draft.objectives.map((s) => s.trim()).filter(Boolean),
      criteria: draft.criteria.map((s) => s.trim()).filter(Boolean),
    };
    setCur(clean);
    localStorage.setItem(KEY, JSON.stringify(clean));
    setEditing(false);
    toast.success("Kandungan kurikulum disimpan dalam pelayar ini.");
  };
  const resetAll = () => {
    localStorage.removeItem(KEY);
    setCur(DEFAULT_CURRICULUM);
    setDraft(DEFAULT_CURRICULUM);
    setEditing(false);
    toast("Kandungan dipulihkan mengikut RPH asal.");
  };

  return (
    <PageShell
      path="/pengenalan"
      segment="Segmen 1 · Set Induksi & Pengenalan"
      subtitle="Mari kenali apa yang akan kita pelajari dan apa yang perlu kamu capai hari ini."
    >
      <div className="grid gap-4 sm:grid-cols-3">
        <InfoCard icon="🏃" color="bg-sky" label="Mata Pelajaran" value={cur.subject} />
        <InfoCard icon="🎒" color="bg-sunny" label="Tahun" value={cur.year} />
        <InfoCard icon="🏐" color="bg-mint" label="Tajuk Kemahiran" value={cur.topic} />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <div className="card-fun p-6">
          <p className="flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wide text-primary">
            <span aria-hidden>🎯</span> Standard Kandungan (SK)
          </p>
          <p className="mt-2 text-lg font-semibold">{cur.sk}</p>
          <p className="mt-5 flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wide text-primary">
            <span aria-hidden>📌</span> Standard Pembelajaran (SP)
          </p>
          <p className="mt-2 text-lg font-semibold">{cur.sp}</p>
        </div>
        <div className="card-fun bg-sunny/40 p-6">
          <p className="flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wide text-sunny-foreground">
            <span aria-hidden>🏆</span> Hasil Pembelajaran
          </p>
          <p className="mt-2 font-display text-2xl font-bold text-primary-deep">{cur.outcome}</p>
        </div>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <div className="card-fun p-6">
          <SectionTitle icon="🧭" hint="Pada akhir pembelajaran, murid dapat:">Objektif Pembelajaran</SectionTitle>
          <ol className="space-y-3">
            {cur.objectives.map((o, i) => (
              <li key={i} className="flex gap-3">
                <span className="grid size-8 shrink-0 place-items-center rounded-full bg-primary font-display font-bold text-primary-foreground">
                  {i + 1}
                </span>
                <span className="pt-1 text-lg">{o}</span>
              </li>
            ))}
          </ol>
        </div>
        <div className="card-fun p-6">
          <SectionTitle icon="✅" hint="Saya berjaya jika:">Kriteria Kejayaan</SectionTitle>
          <ul className="space-y-3">
            {cur.criteria.map((c, i) => (
              <li key={i} className="flex gap-3 rounded-xl bg-mint/60 p-3">
                <span aria-hidden className="text-xl">⭐</span>
                <span className="text-lg">{c}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <section className="mt-10">
        <SectionTitle icon="🧩" hint="Pelajaran ini dirancang mengikut Model ASSURE dalam tiga segmen.">
          Perjalanan Pelajaran Kita
        </SectionTitle>
        <div className="grid gap-4 md:grid-cols-3">
          {[
            { n: 1, t: "Set Induksi & Pengenalan", c: "bg-sky", items: ["Tarik perhatian: situasi permainan", "Persoalan: bagaimana menghantar bola dengan tepat?", "Demonstrasi 2 cara hantaran + hantaran ke sasaran"] },
            { n: 2, t: "Aktiviti Utama & Penerokaan", c: "bg-sunny", items: ["Aktiviti 1: Hantar & Tepat", "Aktiviti 2: Cabaran 3 Zon", "Aktiviti 3: Misi Hantaran Tepat (1–3 mata)"] },
            { n: 3, t: "Aplikasi, Pengukuhan & Penutup", c: "bg-mint", items: ["Aktiviti Aplikasi: Hantaran Menang", "Kuiz e-pentaksiran", "Refleksi Bermakna 3-2-1"] },
          ].map((s) => (
            <div key={s.n} className="card-fun overflow-hidden">
              <div className={`${s.c} flex items-center gap-3 p-4`}>
                <span className="grid size-10 place-items-center rounded-full bg-card font-display text-xl font-extrabold text-primary-deep">
                  {s.n}
                </span>
                <h3 className="font-display text-xl font-bold text-primary-deep">Segmen {s.n}: {s.t}</h3>
              </div>
              <ul className="space-y-2 p-4">
                {s.items.map((it) => (
                  <li key={it} className="flex gap-2"><span aria-hidden>▸</span>{it}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-4 flex flex-wrap gap-2" aria-label="Model ASSURE">
          {[
            ["A", "Analyse Learners", "Menganalisis murid"],
            ["S", "State Objectives", "Menyatakan objektif"],
            ["S", "Select Methods, Media & Materials", "Memilih kaedah, media & bahan"],
            ["U", "Utilize Media & Materials", "Menggunakan media & bahan"],
            ["R", "Require Learner Participation", "Melibatkan penglibatan murid"],
            ["E", "Evaluate & Revise", "Menilai & menambah baik"],
          ].map(([l, en, ms], i) => (
            <span key={i} className="flex items-center gap-2 rounded-full border-2 border-border bg-card px-3 py-1.5 text-sm" title={en}>
              <span className="grid size-6 place-items-center rounded-full bg-primary font-display font-bold text-primary-foreground">{l}</span>
              {ms}
            </span>
          ))}
        </div>
      </section>

      <section className="mt-10 card-fun border-dashed p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl font-bold text-primary-deep">🧑‍🏫 Ruang Guru</h2>
            <p className="text-muted-foreground">
              Semak profil kelas dan sunting standard kurikulum. Suntingan disimpan dalam pelayar ini sahaja.
            </p>
          </div>
          {!editing && (
            <Button variant="soft" size="big" onClick={startEdit}>
              <Pencil /> Sunting Kurikulum
            </Button>
          )}
        </div>

        <div className="mt-5 grid gap-4 md:grid-cols-2">
          <div className="rounded-2xl bg-secondary p-4">
            <h3 className="font-display text-lg font-bold">Profil Kelas (Persona Murid)</h3>
            <p className="mt-1">Tahun 5 · 30 murid · Umur 11 tahun</p>
            <ul className="mt-3 space-y-1.5">
              <li className="flex items-center gap-2"><span className="size-3 rounded-full bg-success" /> 10 murid — menguasai dengan baik</li>
              <li className="flex items-center gap-2"><span className="size-3 rounded-full bg-sunny-strong" /> 15 murid — penguasaan sederhana</li>
              <li className="flex items-center gap-2"><span className="size-3 rounded-full bg-coral" /> 5 murid — memerlukan bimbingan</li>
            </ul>
          </div>
          <div className="rounded-2xl bg-secondary p-4">
            <h3 className="font-display text-lg font-bold">Ciri-ciri & Keperluan Murid</h3>
            <ul className="mt-2 list-disc space-y-1 pl-5">
              <li>Aktif dan suka aktiviti permainan.</li>
              <li>Mempunyai pengalaman asas menghantar bola.</li>
              <li>Lebih berminat dengan aktiviti berbentuk pertandingan dan permainan.</li>
              <li>Tahap koordinasi dan ketepatan berbeza.</li>
              <li>Aktiviti perlu interaktif, berpusatkan murid, berperingkat dan melibatkan pergerakan fizikal.</li>
            </ul>
          </div>
        </div>

        {editing && (
          <div className="mt-6 space-y-4">
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Mata pelajaran">
                <Input value={draft.subject} onChange={(e) => setDraft({ ...draft, subject: e.target.value })} />
              </Field>
              <Field label="Tahun">
                <Input value={draft.year} onChange={(e) => setDraft({ ...draft, year: e.target.value })} />
              </Field>
              <Field label="Tajuk kemahiran">
                <Input value={draft.topic} onChange={(e) => setDraft({ ...draft, topic: e.target.value })} />
              </Field>
            </div>
            <Field label="Standard Kandungan (SK)">
              <Textarea value={draft.sk} onChange={(e) => setDraft({ ...draft, sk: e.target.value })} />
            </Field>
            <Field label="Standard Pembelajaran (SP)">
              <Textarea value={draft.sp} onChange={(e) => setDraft({ ...draft, sp: e.target.value })} />
            </Field>
            <Field label="Objektif (satu baris satu objektif)">
              <Textarea rows={4} value={draft.objectives.join("\n")} onChange={(e) => setDraft({ ...draft, objectives: e.target.value.split("\n") })} />
            </Field>
            <Field label="Kriteria kejayaan (satu baris satu kriteria)">
              <Textarea rows={4} value={draft.criteria.join("\n")} onChange={(e) => setDraft({ ...draft, criteria: e.target.value.split("\n") })} />
            </Field>
            <Field label="Hasil pembelajaran">
              <Textarea value={draft.outcome} onChange={(e) => setDraft({ ...draft, outcome: e.target.value })} />
            </Field>
            <div className="flex flex-wrap gap-3">
              <Button variant="game" size="big" onClick={saveEdit}><Save /> Simpan</Button>
              <Button variant="soft" size="big" onClick={() => setEditing(false)}><X /> Batal</Button>
              <Button variant="soft" size="big" onClick={resetAll}><RotateCcw /> Pulihkan ikut RPH</Button>
            </div>
          </div>
        )}
      </section>
    </PageShell>
  );
}

function InfoCard({ icon, color, label, value }: { icon: string; color: string; label: string; value: string }) {
  return (
    <div className="card-fun flex items-center gap-4 p-5">
      <span className={`${color} grid size-14 shrink-0 place-items-center rounded-2xl text-3xl`} aria-hidden>
        {icon}
      </span>
      <div>
        <p className="text-sm font-bold text-muted-foreground">{label}</p>
        <p className="font-display text-xl font-bold leading-tight text-primary-deep">{value}</p>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-bold">{label}</span>
      {children}
    </label>
  );
}
