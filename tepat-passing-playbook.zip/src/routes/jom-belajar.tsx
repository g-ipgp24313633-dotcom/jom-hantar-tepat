import { PassAnimation } from "@/components/jht/PassAnimation";
import { createFileRoute } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";
import dadaImg from "@/assets/teknik-dada-betul.jpg";
import { PageShell, SectionTitle } from "@/components/jht/PageShell";
import { MatchDrag } from "@/components/jht/MatchDrag";
import { PictureChoice } from "@/components/jht/PictureChoice";
import { VideoSlot } from "@/components/jht/VideoSlot";
import { Button } from "@/components/ui/button";
import { CONCEPT_VIDEO_URL } from "@/config/media";
import { play } from "@/lib/sound";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/jom-belajar")({
  head: () => ({
    meta: [
      { title: "Jom Belajar! | JOM HANTAR TEPAT!" },
      { name: "description", content: "Maksud hantaran, kepentingan ketepatan, pelbagai cara hantaran dan langkah teknik menghantar bola ke sasaran." },
      { property: "og:title", content: "Jom Belajar! | JOM HANTAR TEPAT!" },
      { property: "og:description", content: "Kad interaktif dan langkah demi langkah teknik hantaran bola ke sasaran untuk Tahun 5." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: JomBelajar,
});

const STORY = [
  { icon: "⚽", title: "1. Tarik Perhatian", text: "Lihat situasi permainan! Pasukan perlu menghantar bola kepada rakan untuk menjaringkan mata.", bg: "bg-sky" },
  { icon: "🤔", title: "2. Persoalan", text: "Bagaimanakah cara menghantar bola dengan tepat sehingga sampai ke sasaran?", bg: "bg-sunny" },
  { icon: "🧑‍🏫", title: "3. Demonstrasi", text: "Guru menunjukkan 2 cara hantaran (hantaran dada & hantaran lantun) serta hantaran ke sasaran.", bg: "bg-mint" },
  { icon: "🎯", title: "4. Cabaran", text: "Bolehkah kamu mencapai sasaran? Jom cuba dalam Cabaran Hantar Tepat nanti!", bg: "bg-coral-soft" },
];

const FLIP = [
  { front: "Apakah maksud hantaran?", icon: "🔁", back: "Hantaran ialah cara memindahkan bola kepada rakan sepasukan atau ke sasaran menggunakan alatan atau anggota badan yang dibenarkan." },
  { front: "Mengapa hantaran perlu tepat?", icon: "🎯", back: "Hantaran yang tepat membantu pasukan mengekalkan bola, mengelak bola dipintas lawan dan mendekati gol." },
  { front: "Anggota badan yang boleh digunakan?", icon: "✋", back: "Tangan (bola jaring, bola baling), kaki (bola sepak) dan alatan seperti kayu hoki — ikut peraturan permainan." },
];

const PASSES = [
  { name: "Hantaran Dada", tool: "Tangan", icon: "🤲", when: "Rakan dekat, tiada halangan.", how: "Pegang bola di paras dada, tolak ke hadapan dengan kedua-dua tangan." },
  { name: "Hantaran Lantun", tool: "Tangan", icon: "⬇️", when: "Ada lawan menghalang di hadapan.", how: "Tolak bola ke lantai, kira-kira ⅔ jarak ke arah rakan." },
  { name: "Hantaran Atas Kepala", tool: "Tangan", icon: "🙌", when: "Rakan jauh atau perlu melepasi lawan.", how: "Angkat bola di atas kepala, lontar dengan kedua-dua tangan." },
  { name: "Hantaran Kaki (Sisi Kaki)", tool: "Kaki", icon: "🦶", when: "Permainan bola sepak.", how: "Tendang bola dengan bahagian dalam kaki ke arah rakan." },
  { name: "Hantaran Tolak Hoki", tool: "Kayu hoki", icon: "🏑", when: "Permainan hoki.", how: "Letak kayu di belakang bola dan tolak ke arah sasaran." },
];

const STEPS = [
  { title: "Bersedia", icon: "🧍", text: "Berdiri dengan kaki selebar bahu. Pegang bola di paras dada, jari terbuka dan ibu jari di belakang bola.", focus: "Badan seimbang" },
  { title: "Lihat Sasaran", icon: "👀", text: "Mata memandang tepat ke sasaran atau tangan rakan sebelum melepaskan bola.", focus: "Mata fokus" },
  { title: "Langkah & Tolak", icon: "🦵", text: "Langkah satu kaki ke hadapan ke arah sasaran sambil menolak bola dengan kedua-dua tangan.", focus: "Kaki melangkah" },
  { title: "Ikut Lajak", icon: "👉", text: "Luruskan tangan ke arah sasaran selepas bola dilepaskan. Tapak tangan menghala ke luar.", focus: "Tangan lurus ke sasaran" },
];

const FORMATIF = [
  { q: "Apakah yang dimaksudkan dengan hantaran?", a: "Memindahkan bola kepada rakan sepasukan atau ke sasaran." },
  { q: "Mengapakah bola perlu dihantar dengan tepat?", a: "Supaya bola sampai kepada rakan, tidak dipintas lawan dan pasukan boleh menyerang." },
  { q: "Apakah anggota badan yang boleh digunakan?", a: "Tangan, kaki, atau alatan seperti kayu hoki — mengikut permainan." },
];

function JomBelajar() {
  const [story, setStory] = useState(0);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [pass, setPass] = useState(0);
  const [step, setStep] = useState(0);
  const [shown, setShown] = useState<number[]>([]);

  const cs = STORY[story]!;
  const cp = PASSES[pass]!;
  const cst = STEPS[step]!;

  const toggle = (arr: number[], i: number) => (arr.includes(i) ? arr.filter((x) => x !== i) : [...arr, i]);

  return (
    <PageShell path="/jom-belajar" segment="Segmen 1 · Set Induksi & Pengenalan" subtitle="Tekan kad, ikut langkah dan uji diri kamu. Belajar sedikit demi sedikit!">
      <section className="card-fun mb-8 p-6">
        <SectionTitle icon="🎬" hint="Tonton bola bergerak. Tekan butang untuk tukar jenis hantaran.">Animasi Hantaran</SectionTitle>
        <PassAnimation />
      </section>

      {/* Storyboard 4 frame */}
      <section className="card-fun p-6">
        <SectionTitle icon="🎞️" hint="Ikuti cerita ringkas pelajaran hari ini.">Storyboard Kita</SectionTitle>
        <div className="grid gap-4 md:grid-cols-[1fr_auto] md:items-center">
          <div className={cn("animate-pop flex items-center gap-5 rounded-2xl p-6", cs.bg)} key={story}>
            <span className="animate-float text-6xl" aria-hidden>{cs.icon}</span>
            <div>
              <h3 className="font-display text-2xl font-bold text-primary-deep">{cs.title}</h3>
              <p className="mt-1 text-lg">{cs.text}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 md:flex-col">
            <Button variant="soft" size="icon" className="size-12" aria-label="Bingkai sebelum" disabled={story === 0} onClick={() => setStory(story - 1)}>
              <ChevronLeft />
            </Button>
            <Button variant="game" size="icon" className="size-12" aria-label="Bingkai seterusnya" disabled={story === STORY.length - 1} onClick={() => { play("click"); setStory(story + 1); }}>
              <ChevronRight />
            </Button>
          </div>
        </div>
        <div className="mt-3 flex gap-2">
          {STORY.map((s, i) => (
            <button key={i} type="button" onClick={() => setStory(i)} aria-label={s.title} className={cn("h-2.5 flex-1 rounded-full", i <= story ? "bg-primary" : "bg-secondary")} />
          ))}
        </div>
      </section>

      {/* Flip cards */}
      <section className="mt-8">
        <SectionTitle icon="💡" hint="Tekan setiap kad untuk melihat jawapan.">Apa Itu Hantaran?</SectionTitle>
        <div className="grid gap-4 md:grid-cols-3">
          {FLIP.map((f, i) => {
            const open = flipped.includes(i);
            return (
              <button
                key={i}
                type="button"
                onClick={() => { play("click"); setFlipped(toggle(flipped, i)); }}
                aria-pressed={open}
                className={cn("card-fun min-h-48 p-6 text-left transition-all hover:-translate-y-1", open ? "bg-mint" : "bg-card")}
              >
                <span className="inline-block animate-float text-4xl" aria-hidden>{f.icon}</span>
                <p className="mt-2 font-display text-xl font-bold text-primary-deep">{f.front}</p>
                {open ? (
                  <p className="animate-pop mt-2 text-lg">{f.back}</p>
                ) : (
                  <p className="mt-2 text-sm font-bold text-primary">Tekan untuk lihat jawapan →</p>
                )}
              </button>
            );
          })}
        </div>
      </section>

      {/* Pelbagai cara hantaran */}
      <section className="mt-8 card-fun p-6">
        <SectionTitle icon="🧰" hint="Pilih satu cara hantaran untuk mengetahui bila dan bagaimana menggunakannya.">
          Pelbagai Cara Hantaran
        </SectionTitle>
        <div className="flex flex-wrap gap-2" role="tablist">
          {PASSES.map((p, i) => (
            <button
              key={p.name}
              type="button"
              role="tab"
              aria-selected={pass === i}
              onClick={() => setPass(i)}
              className={cn("rounded-xl px-4 py-2 font-display font-semibold transition-colors", pass === i ? "bg-primary text-primary-foreground" : "bg-secondary hover:bg-sky")}
            >
              <span aria-hidden>{p.icon}</span> {p.name}
            </button>
          ))}
        </div>
        <div key={pass} className="animate-pop mt-4 grid gap-3 sm:grid-cols-3">
          <div className="rounded-2xl bg-sky p-4"><p className="text-sm font-bold text-muted-foreground">Alatan / anggota badan</p><p className="font-display text-xl font-bold">{cp.tool}</p></div>
          <div className="rounded-2xl bg-sunny p-4"><p className="text-sm font-bold text-sunny-foreground">Bila digunakan?</p><p className="text-lg">{cp.when}</p></div>
          <div className="rounded-2xl bg-mint p-4"><p className="text-sm font-bold text-mint-foreground">Bagaimana?</p><p className="text-lg">{cp.how}</p></div>
        </div>
      </section>

      {/* Langkah teknik */}
      <section className="mt-8 card-fun p-6">
        <SectionTitle icon="🪜" hint="Contoh: hantaran dada ke sasaran. Tekan setiap langkah.">4 Langkah Hantar Tepat</SectionTitle>
        <div className="grid gap-6 lg:grid-cols-2 lg:items-center">
          <div className="relative">
            <img src={dadaImg} alt="Murid melakukan hantaran dada yang betul ke arah sasaran" width={1024} height={1024} loading="lazy" className="aspect-square w-full rounded-2xl object-cover" />
            <span key={step} className="animate-pop absolute bottom-3 left-3 rounded-xl bg-sunny px-3 py-1.5 font-display font-bold text-sunny-foreground shadow-chunky-sunny">
              Fokus: {cst.focus}
            </span>
          </div>
          <div>
            <ol className="space-y-3">
              {STEPS.map((s, i) => (
                <li key={s.title}>
                  <button
                    type="button"
                    onClick={() => { play("click"); setStep(i); }}
                    className={cn("flex w-full items-start gap-4 rounded-2xl border-2 p-4 text-left transition-all", step === i ? "border-primary bg-secondary" : "border-border bg-card hover:border-sky-strong")}
                    aria-current={step === i ? "step" : undefined}
                  >
                    <span className={cn("grid size-11 shrink-0 place-items-center rounded-xl font-display text-xl font-bold", step === i ? "bg-primary text-primary-foreground" : "bg-secondary")}>{i + 1}</span>
                    <span>
                      <span className="block font-display text-xl font-bold text-primary-deep"><span aria-hidden>{s.icon}</span> {s.title}</span>
                      {step === i && <span className="animate-pop mt-1 block text-lg">{s.text}</span>}
                    </span>
                  </button>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      {/* Video konsep */}
      <section className="mt-8 card-fun p-6">
        <SectionTitle icon="🎬" hint="Tonton video penerangan konsep hantaran.">Video Penerangan</SectionTitle>
        <VideoSlot url={CONCEPT_VIDEO_URL} title="Video penerangan konsep hantaran bola" />
      </section>

      {/* Pentaksiran formatif awal */}
      <section className="mt-8 card-fun p-6">
        <SectionTitle icon="🗣️" hint="Fikir dahulu, kemudian tekan untuk semak jawapan.">Soal Jawab Ringkas</SectionTitle>
        <div className="space-y-3">
          {FORMATIF.map((f, i) => (
            <div key={i} className="rounded-2xl border-2 border-border p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="font-display text-lg font-bold">{i + 1}. {f.q}</p>
                <Button variant="soft" size="sm" onClick={() => setShown(toggle(shown, i))}>
                  {shown.includes(i) ? "Sembunyi" : "Semak jawapan"}
                </Button>
              </div>
              {shown.includes(i) && <p className="animate-pop mt-2 rounded-xl bg-mint p-3">{f.a}</p>}
            </div>
          ))}
        </div>
      </section>

      {/* Aktiviti pilihan gambar */}
      <section className="mt-8 card-fun p-6">
        <SectionTitle icon="🧩" hint="Padankan setiap teknik dengan penerangannya.">Aktiviti: Padankan Teknik</SectionTitle>
        <MatchDrag />
        <div className="mt-8" />
        <SectionTitle icon="🖼️" hint="Pilih gambar yang betul untuk setiap soalan.">Aktiviti: Kenal Pasti Teknik Betul</SectionTitle>
        <PictureChoice />
      </section>
    </PageShell>
  );
}
