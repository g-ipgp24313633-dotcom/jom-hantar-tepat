import { createFileRoute, Link } from "@tanstack/react-router";
import { Dumbbell, Home, Sparkles, Star, Target, UserRound } from "lucide-react";
import { DeveloperProfile } from "@/components/jht/DeveloperProfile";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/profil-pembangun")({
  head: () => ({
    meta: [
      { title: "Profil Pembangun | JOM HANTAR TEPAT!" },
      {
        name: "description",
        content: "Kenali Veronika Alexsia Anak Miger, guru pelatih Pendidikan Jasmani dan pembangun laman JOM HANTAR TEPAT!",
      },
      { property: "og:title", content: "Profil Pembangun | JOM HANTAR TEPAT!" },
      {
        property: "og:description",
        content: "Portfolio pembangun bahan pembelajaran digital interaktif Pendidikan Jasmani Tahun 5.",
      },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  return (
    <main className="min-h-[calc(100vh-110px)] bg-background">
      <section className="relative isolate animate-profile-gradient overflow-hidden bg-profile-hero px-4 pt-12 pb-28 text-center sm:pt-16 sm:pb-32">
        <div className="pointer-events-none absolute inset-0" aria-hidden>
          <span className="absolute top-10 left-[7%] size-28 rounded-full border-2 border-primary/10 sm:size-40" />
          <span className="absolute right-[5%] bottom-16 size-36 rounded-full border-2 border-mint-foreground/10 sm:size-52" />
          <Star className="absolute top-[22%] left-[12%] size-7 animate-profile-float text-sunny-strong/50" />
          <Sparkles className="absolute top-[18%] right-[13%] size-8 animate-profile-float text-primary/25 [animation-delay:500ms]" />
          <Dumbbell className="absolute right-[8%] bottom-[24%] hidden size-12 rotate-12 animate-profile-float text-mint-foreground/25 sm:block" />
          <Target className="absolute bottom-[20%] left-[9%] hidden size-12 animate-profile-float text-primary/15 [animation-delay:700ms] sm:block" />
        </div>

        <div className="relative animate-profile-reveal [animation-fill-mode:both]">
          <p className="inline-flex items-center gap-2 rounded-full border-2 border-card/80 bg-card/70 px-4 py-2 font-sans text-xs font-extrabold tracking-[0.18em] text-primary shadow-card backdrop-blur-xl sm:text-sm">
            <UserRound className="size-4" aria-hidden /> PROFIL PEMBANGUN
          </p>
          <h1 className="mt-5 font-sans text-4xl font-extrabold tracking-tight text-primary-deep sm:text-5xl lg:text-6xl">
            KENALI <span className="text-primary">PEMBANGUN</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            Portfolio pendidikan digital yang menghubungkan kreativiti, teknologi dan pembelajaran aktif.
          </p>
        </div>

        <svg className="absolute -bottom-px left-0 h-14 w-full text-background sm:h-20" viewBox="0 0 1440 120" preserveAspectRatio="none" aria-hidden>
          <path d="M0 66C240 112 420 8 720 54C1010 98 1210 20 1440 54V120H0Z" fill="currentColor" />
        </svg>
      </section>

      <div className="relative z-10 mx-auto -mt-16 max-w-6xl px-4 pb-16 sm:-mt-18">
        <DeveloperProfile />

        <section className="relative mt-8 overflow-hidden rounded-3xl bg-primary px-6 py-10 text-center text-primary-foreground shadow-card sm:px-10 sm:py-12">
          <Sparkles className="absolute top-5 left-6 size-8 text-primary-foreground/20" aria-hidden />
          <Star className="absolute right-7 bottom-5 size-10 text-primary-foreground/15" aria-hidden />
          <p className="relative font-display text-3xl font-bold sm:text-4xl">“Belajar dengan seronok, bergerak dengan yakin!”</p>
          <Button asChild variant="sunny" size="big" className="relative mt-6 w-full sm:w-auto">
            <Link to="/">
              <Home /> KEMBALI KE LAMAN UTAMA
            </Link>
          </Button>
        </section>
      </div>
    </main>
  );
}
