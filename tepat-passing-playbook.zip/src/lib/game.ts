/**
 * Pure rules for "Cabaran Hantar Tepat!" (RPH Segmen 2: Cabaran 3 Zon + Misi Hantaran Tepat).
 * Zon dekat = 1 mata, zon sederhana = 2 mata, zon jauh = 3 mata.
 */
export const FIELD_W = 400;
export const FIELD_H = 600;
export const BALL_START = { x: 200, y: 540 };
export const MAX_DRAG = 160;
export const MAX_DIST = 520;
export const ATTEMPTS_PER_LEVEL = 5;

export type LevelId = 1 | 2 | 3;

export type Level = {
  id: LevelId;
  name: string;
  zone: string;
  label: string;
  points: number;
  targetY: number;
  radius: number;
  /** Horizontal range the target can appear in (centre x). */
  xRange: [number, number];
};

export const LEVELS: Record<LevelId, Level> = {
  1: { id: 1, name: "Tahap 1", zone: "Zon 1", label: "Sasaran dekat (mudah)", points: 1, targetY: 390, radius: 46, xRange: [200, 200] },
  2: { id: 2, name: "Tahap 2", zone: "Zon 2", label: "Sasaran sederhana", points: 2, targetY: 250, radius: 38, xRange: [130, 270] },
  3: { id: 3, name: "Tahap 3", zone: "Zon 3", label: "Sasaran jauh (cabaran)", points: 3, targetY: 115, radius: 32, xRange: [90, 310] },
};

export const MAX_TOTAL = (Object.values(LEVELS) as Level[]).reduce(
  (sum, l) => sum + l.points * ATTEMPTS_PER_LEVEL,
  0,
);

export type Point = { x: number; y: number };

export type Shot = { dirX: number; dirY: number; power: number; landing: Point };

/** Slingshot aim: drag backwards from the ball; the ball flies the opposite way. */
export function computeShot(start: Point, pointer: Point): Shot | null {
  const dx = start.x - pointer.x;
  const dy = start.y - pointer.y;
  const len = Math.hypot(dx, dy);
  if (len < 8) return null;
  const power = Math.min(len / MAX_DRAG, 1);
  const dirX = dx / len;
  const dirY = dy / len;
  const dist = power * MAX_DIST;
  return { dirX, dirY, power, landing: { x: start.x + dirX * dist, y: start.y + dirY * dist } };
}

export function isHit(landing: Point, target: Point, radius: number): boolean {
  return Math.hypot(landing.x - target.x, landing.y - target.y) <= radius;
}

export function pointsFor(level: LevelId, hit: boolean): number {
  return hit ? LEVELS[level].points : 0;
}

export function targetFor(level: LevelId, rand: () => number = Math.random): Point {
  const [a, b] = LEVELS[level].xRange;
  return { x: a + (b - a) * rand(), y: LEVELS[level].targetY };
}

const HIT_MSGS = ["Hebat! Tepat ke sasaran! 🎯", "Syabas! Teruskan usaha! 🌟", "Wah, juara hantaran! 🏆", "Cantik! Mata kamu fokus! 👀"];

/** Coaching message after a throw, so the pupil knows what to fix. */
export function feedback(landing: Point, target: Point, radius: number, hit: boolean, n = 0): string {
  if (hit) return HIT_MSGS[n % HIT_MSGS.length]!;
  const short = landing.y > target.y + radius * 0.6;
  const long = landing.y < target.y - radius * 0.6;
  const left = landing.x < target.x - radius * 0.6;
  const right = landing.x > target.x + radius * 0.6;
  const tips: string[] = [];
  if (short) tips.push("tambah sedikit kekuatan");
  if (long) tips.push("kurangkan kekuatan");
  if (left) tips.push("halakan sedikit ke kanan");
  if (right) tips.push("halakan sedikit ke kiri");
  const tip = tips.length ? tips.join(" dan ") : "fokus pada tengah sasaran";
  return `Hampir! Cuba ${tip}. Kamu boleh! 💪`;
}
