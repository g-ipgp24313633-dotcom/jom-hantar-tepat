import { useSyncExternalStore } from "react";
import { PAGES, type ActivityId, type PagePath } from "./pages";

/**
 * Learner progress kept only in this browser (no login, no personal data).
 */
export type Progress = {
  visited: PagePath[];
  done: ActivityId[];
  best: Partial<Record<"cabaran" | "kuiz", number>>;
};

const KEY = "jht-progress-v1";
const EMPTY: Progress = { visited: [], done: [], best: {} };

let state: Progress = EMPTY;
let loaded = false;
const listeners = new Set<() => void>();

function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw) state = { ...EMPTY, ...JSON.parse(raw) };
  } catch {
    state = EMPTY;
  }
}

function save(next: Progress) {
  state = next;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* storage may be blocked; progress then lasts for this visit only */
  }
  listeners.forEach((l) => l());
}

function subscribe(cb: () => void) {
  load();
  listeners.add(cb);
  cb();
  return () => listeners.delete(cb);
}

export function useProgress(): Progress {
  return useSyncExternalStore(
    subscribe,
    () => {
      load();
      return state;
    },
    () => EMPTY,
  );
}

export function markVisited(path: PagePath) {
  load();
  if (state.visited.includes(path)) return;
  save({ ...state, visited: [...state.visited, path] });
}

export function markDone(id: ActivityId) {
  load();
  if (state.done.includes(id)) return;
  save({ ...state, done: [...state.done, id] });
}

export function recordBest(key: "cabaran" | "kuiz", score: number) {
  load();
  const prev = state.best[key] ?? 0;
  if (score <= prev) return;
  save({ ...state, best: { ...state.best, [key]: score } });
}

export function resetProgress() {
  load();
  save(EMPTY);
}

export function isStepComplete(p: Progress, path: PagePath): boolean {
  const page = PAGES.find((x) => x.path === path);
  if (!page) return false;
  return page.activity ? p.done.includes(page.activity) : p.visited.includes(path);
}

export function percentComplete(p: Progress): number {
  const n = PAGES.filter((pg) => isStepComplete(p, pg.path)).length;
  return Math.round((n / PAGES.length) * 100);
}
