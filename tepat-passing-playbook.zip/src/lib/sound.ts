import { useSyncExternalStore } from "react";

/** Small synthesized sound effects (no audio files needed) with a global mute switch. */
const KEY = "jht-muted";
let muted = false;
let loaded = false;
const listeners = new Set<() => void>();
let ctx: AudioContext | null = null;

function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  muted = window.localStorage.getItem(KEY) === "1";
}

export function useMuted() {
  return useSyncExternalStore(
    (cb) => {
      load();
      listeners.add(cb);
      cb();
      return () => listeners.delete(cb);
    },
    () => {
      load();
      return muted;
    },
    () => false,
  );
}

export function setMuted(value: boolean) {
  muted = value;
  try {
    window.localStorage.setItem(KEY, value ? "1" : "0");
  } catch {
    /* ignore */
  }
  listeners.forEach((l) => l());
}

function audio(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

function tone(freq: number, start: number, dur: number, type: OscillatorType = "sine", vol = 0.15) {
  const a = audio();
  if (!a) return;
  const t = a.currentTime + start;
  const o = a.createOscillator();
  const g = a.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(a.destination);
  o.start(t);
  o.stop(t + dur + 0.05);
}

export type Sfx = "click" | "correct" | "wrong" | "throw" | "hit" | "miss" | "win";

export function play(sfx: Sfx) {
  load();
  if (muted) return;
  switch (sfx) {
    case "click":
      tone(660, 0, 0.08, "triangle", 0.08);
      break;
    case "correct":
      tone(660, 0, 0.12, "triangle");
      tone(880, 0.1, 0.18, "triangle");
      break;
    case "wrong":
      tone(240, 0, 0.18, "sawtooth", 0.07);
      tone(180, 0.15, 0.25, "sawtooth", 0.07);
      break;
    case "throw":
      tone(320, 0, 0.12, "sine", 0.1);
      tone(480, 0.05, 0.12, "sine", 0.08);
      break;
    case "hit":
      tone(523, 0, 0.1, "square", 0.08);
      tone(784, 0.08, 0.12, "square", 0.08);
      tone(1046, 0.16, 0.2, "square", 0.08);
      break;
    case "miss":
      tone(300, 0, 0.2, "triangle", 0.08);
      break;
    case "win":
      [523, 659, 784, 1046].forEach((f, i) => tone(f, i * 0.12, 0.22, "triangle", 0.12));
      break;
  }
}
