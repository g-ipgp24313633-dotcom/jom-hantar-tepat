export type QuizQuestion = {
  id: string;
  topic: "Teknik" | "Ketepatan" | "Keselamatan" | "Situasi Permainan";
  question: string;
  options: [string, string, string, string];
  /** Index of the correct option in `options`. */
  answer: number;
  explain: string;
};

export const QUIZ: QuizQuestion[] = [
  {
    id: "q1",
    topic: "Teknik",
    question: "Apakah maksud hantaran dalam permainan?",
    options: [
      "Memindahkan bola kepada rakan sepasukan atau ke sasaran",
      "Memegang bola selama yang boleh",
      "Melantun bola di tempat sendiri",
      "Menendang bola keluar dari padang",
    ],
    answer: 0,
    explain: "Hantaran ialah cara memindahkan bola kepada rakan atau ke sasaran.",
  },
  {
    id: "q2",
    topic: "Teknik",
    question: "Semasa hantaran dada, di manakah bola dipegang?",
    options: ["Di atas kepala", "Di paras dada", "Di paras lutut", "Di belakang badan"],
    answer: 1,
    explain: "Bola dipegang dengan kedua-dua tangan di paras dada, ibu jari di belakang bola.",
  },
  {
    id: "q3",
    topic: "Ketepatan",
    question: "Mengapakah mata perlu melihat sasaran semasa menghantar bola?",
    options: [
      "Supaya bola menjadi lebih berat",
      "Supaya lawan menjadi keliru",
      "Supaya hantaran lebih tepat ke sasaran",
      "Supaya kita boleh berehat",
    ],
    answer: 2,
    explain: "Mata yang fokus pada sasaran membantu bola sampai dengan tepat.",
  },
  {
    id: "q4",
    topic: "Teknik",
    question: "Bagaimanakah kedudukan kaki yang betul semasa menghantar bola?",
    options: [
      "Kedua-dua kaki rapat",
      "Berdiri di atas satu kaki",
      "Kaki bersilang",
      "Satu kaki melangkah ke hadapan ke arah sasaran",
    ],
    answer: 3,
    explain: "Melangkah ke hadapan memberi imbangan dan kekuatan pada hantaran.",
  },
  {
    id: "q5",
    topic: "Situasi Permainan",
    question: "Hantaran lantun paling sesuai digunakan apabila...",
    options: [
      "ada lawan menghalang di antara kamu dan rakan",
      "rakan berada sangat jauh",
      "tiada rakan di dalam padang",
      "permainan sudah tamat",
    ],
    answer: 0,
    explain: "Bola yang dilantun ke lantai sukar dipintas oleh lawan yang menghalang.",
  },
  {
    id: "q6",
    topic: "Ketepatan",
    question: "Selepas bola dilepaskan, apakah yang perlu dilakukan oleh tangan?",
    options: [
      "Disilangkan ke dada",
      "Diluruskan ke arah sasaran (ikut lajak)",
      "Diletakkan di pinggang",
      "Disembunyikan di belakang",
    ],
    answer: 1,
    explain: "Ikut lajak ke arah sasaran membantu bola bergerak lurus dan tepat.",
  },
  {
    id: "q7",
    topic: "Keselamatan",
    question: "Apakah yang perlu dilakukan sebelum memulakan aktiviti hantaran?",
    options: [
      "Terus berlari selaju-lajunya",
      "Makan dengan banyak",
      "Melakukan aktiviti memanaskan badan",
      "Duduk dan berehat sahaja",
    ],
    answer: 2,
    explain: "Memanaskan badan menyediakan otot dan mengelakkan kecederaan.",
  },
  {
    id: "q8",
    topic: "Keselamatan",
    question: "Bagaimanakah cara menghantar bola dengan selamat kepada rakan?",
    options: [
      "Baling sekuat hati ke arah muka rakan",
      "Hantar ketika rakan sedang berpaling",
      "Hantar sambil menutup mata",
      "Panggil nama rakan dan pastikan dia bersedia",
    ],
    answer: 3,
    explain: "Komunikasi memastikan rakan bersedia menerima bola dengan selamat.",
  },
  {
    id: "q9",
    topic: "Situasi Permainan",
    question: "Rakan sepasukan berada di ruang kosong berhampiran gol. Apakah tindakan terbaik?",
    options: [
      "Hantar bola dengan tepat kepadanya",
      "Simpan bola untuk diri sendiri",
      "Hantar bola kepada pihak lawan",
      "Buang bola keluar padang",
    ],
    answer: 0,
    explain: "Dalam permainan serangan, hantar kepada rakan di ruang kosong untuk menjaringkan mata.",
  },
  {
    id: "q10",
    topic: "Situasi Permainan",
    question: "Dalam permainan bola sepak, anggota badan yang digunakan untuk menghantar bola ialah...",
    options: ["Tangan", "Kaki", "Siku", "Bahu"],
    answer: 1,
    explain: "Bola sepak menggunakan kaki. Setiap permainan ada alatan dan anggota badan yang dibenarkan.",
  },
];

export function shuffle<T>(arr: readonly T[], rand: () => number = Math.random): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    const t = a[i]!;
    a[i] = a[j]!;
    a[j] = t;
  }
  return a;
}

export function quizResult(score: number, total: number) {
  const pct = total ? score / total : 0;
  if (pct >= 0.9) return { badge: "🏆", title: "Juara Hantaran!", msg: "Luar biasa! Kamu benar-benar memahami kemahiran menghantar bola." };
  if (pct >= 0.7) return { badge: "🥈", title: "Pemain Bintang!", msg: "Bagus! Sedikit lagi untuk menjadi juara." };
  if (pct >= 0.5) return { badge: "🥉", title: "Pemain Berusaha!", msg: "Baik! Ulang kaji halaman Jom Belajar dan cuba lagi." };
  return { badge: "💪", title: "Jangan Putus Asa!", msg: "Mari belajar semula langkah hantaran dan cuba sekali lagi." };
}
