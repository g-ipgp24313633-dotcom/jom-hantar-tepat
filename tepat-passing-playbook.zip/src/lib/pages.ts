export type PagePath =
  | "/"
  | "/pengenalan"
  | "/jom-belajar"
  | "/video"
  | "/cabaran"
  | "/kuiz"
  | "/refleksi";

export type PageInfo = {
  path: PagePath;
  no: number;
  title: string;
  short: string;
  emoji: string;
  /** Activity that must be completed to tick this step; pages without one tick on visit. */
  activity?: ActivityId;
};

export type ActivityId = "kenal-teknik" | "video" | "cabaran" | "kuiz" | "refleksi";

export const PAGES: PageInfo[] = [
  { path: "/", no: 1, title: "Laman Utama", short: "Utama", emoji: "🏠" },
  { path: "/pengenalan", no: 2, title: "Kenali Pembelajaran Kita", short: "Kenali", emoji: "🎯" },
  { path: "/jom-belajar", no: 3, title: "Jom Belajar!", short: "Belajar", emoji: "📘", activity: "kenal-teknik" },
  { path: "/video", no: 4, title: "Video Interaktif", short: "Video", emoji: "🎬", activity: "video" },
  { path: "/cabaran", no: 5, title: "Cabaran Hantar Tepat!", short: "Cabaran", emoji: "🏐", activity: "cabaran" },
  { path: "/kuiz", no: 6, title: "Kuiz Juara Hantaran", short: "Kuiz", emoji: "🏆", activity: "kuiz" },
  { path: "/refleksi", no: 7, title: "Refleksi Pembelajaran", short: "Refleksi", emoji: "💭", activity: "refleksi" },
];

export function pageIndex(pathname: string): number {
  const clean = pathname.replace(/\/+$/, "") || "/";
  return PAGES.findIndex((p) => p.path === clean);
}
