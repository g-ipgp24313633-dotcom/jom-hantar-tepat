import { createServerFn } from "@tanstack/react-start";

export type Analysis = { ok: true; text: string } | { ok: false; error: string };

export const analyzeReflections = createServerFn({ method: "POST" })
  .inputValidator((d: { text: string }) => {
    const text = String(d?.text ?? "").trim();
    if (text.length < 10) throw new Error("Sila masukkan jawapan refleksi murid.");
    return { text: text.slice(0, 12000) };
  })
  .handler(async ({ data }): Promise<Analysis> => {
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) return { ok: false, error: "Perkhidmatan AI belum disediakan." };
    const { createOpenAI } = await import("@ai-sdk/openai");
    const { streamText } = await import("ai");
    const openai = createOpenAI({
      baseURL: "https://ai.gateway.lovable.dev/v1",
      apiKey: key,
      headers: { "Lovable-API-Key": key, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    });
    try {
      let err: unknown;
      const result = streamText({
        model: openai.responses("openai/gpt-6-astra"),
        maxRetries: 0,
        onError: ({ error }) => { err = error; },
        providerOptions: {
          openai: { forceReasoning: true, reasoningEffort: "low", reasoningSummary: "auto", store: false, include: ["reasoning.encrypted_content"] },
        },
        system:
          "Anda pembantu guru Pendidikan Jasmani Tahun 5 (SK 1.6, SP 1.6.1: kemahiran menghantar bola dengan tepat ke sasaran). Analisis jawapan refleksi murid. Jawab dalam Bahasa Melayu, ringkas, guna tajuk Markdown: '## Ringkasan Kelas', '## Keperluan Pembelajaran' (kumpulkan murid: menguasai / sedang membangun / perlu bimbingan, dengan bukti dari jawapan), '## Cadangan Tindakan Susulan' (aktiviti pengayaan, pemulihan dan latihan konkrit), '## Murid Perlu Perhatian'. Jangan reka maklumat yang tiada dalam jawapan.",
        prompt: `Jawapan refleksi murid:\n\n${data.text}`,
      });
      const text = await result.text;
      if (err || !text.trim()) {
        console.error("AI analyze error", err);
        const status = (err as { statusCode?: number })?.statusCode;
        if (status === 402) return { ok: false, error: "Kredit AI tidak mencukupi. Tambah kredit di Settings → Plans & credits." };
        if (status === 429) return { ok: false, error: "Terlalu banyak permintaan. Cuba lagi sebentar." };
        return { ok: false, error: "AI tidak dapat menganalisis sekarang. Cuba lagi kemudian." };
      }
      return { ok: true, text };
    } catch (e) {
      console.error("AI analyze error", e);
      return { ok: false, error: "AI tidak dapat menganalisis sekarang. Cuba lagi kemudian." };
    }
  });
