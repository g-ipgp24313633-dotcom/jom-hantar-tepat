import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";
import { DeveloperProfile } from "@/components/jht/DeveloperProfile";

afterEach(() => {
  cleanup();
  window.localStorage.clear();
});

describe("Profil Pembangun privacy", () => {
  it("keeps the identification number hidden until explicitly activated", () => {
    render(<DeveloperProfile />);

    expect(screen.queryByText("060102-13-0258")).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Papar nombor peribadi" }));
    expect(screen.getByText("060102-13-0258")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Sembunyikan nombor peribadi" }));
    expect(screen.queryByText("060102-13-0258")).not.toBeInTheDocument();
  });

  it("keeps the candidate number hidden until explicitly activated", () => {
    render(<DeveloperProfile />);

    expect(screen.queryByText("2025312440239")).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Papar nombor peribadi" }));
    expect(screen.getByText("2025312440239")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Sembunyikan nombor peribadi" }));
    expect(screen.queryByText("2025312440239")).not.toBeInTheDocument();
  });
});
