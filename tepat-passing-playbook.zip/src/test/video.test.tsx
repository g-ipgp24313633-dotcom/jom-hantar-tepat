import { fireEvent, render, screen, cleanup } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { InteractiveVideo } from "@/components/jht/InteractiveVideo";
import { cueTimes, parseVideoUrl, VIDEO_CUES } from "@/config/media";
vi.mock("@/lib/progress", () => ({ markDone: vi.fn() }));
import { markDone } from "@/lib/progress";
afterEach(() => { cleanup(); vi.clearAllMocks(); });
describe("Video activity", () => {
  it("uses the supplied YouTube video", () => {
    expect(parseVideoUrl("https://youtu.be/fICWh8jp00k?si=hil5ncwYhJhsTHzI")).toEqual({ kind: "youtube", id: "fICWh8jp00k" });
  });
  it("keeps the three RPH question times for a long video", () => {
    expect(cueTimes(VIDEO_CUES, 120)).toEqual([20, 45, 70]);
  });
  it("redistributes every question in order for a short video", () => {
    expect(cueTimes(VIDEO_CUES, 60)).toEqual([15, 30, 45]);
  });
  it("completes only after all three answers and scores correct answers", () => {
    render(<InteractiveVideo url="" />);
    for (let index = 0; index < 3; index++) {
      expect(markDone).not.toHaveBeenCalled();
      fireEvent.click(screen.getByRole("button", { name: /Soalan seterusnya/ }));
      const cue = VIDEO_CUES[index];
      if (!cue) throw new Error("Missing question");
      const answer = index === 0 ? 1 : cue.answer;
      fireEvent.click(screen.getByRole("button", { name: `${String.fromCharCode(65 + answer)}. ${cue.options[answer]}` }));
      expect(markDone).not.toHaveBeenCalled();
      fireEvent.click(screen.getByRole("button", { name: index === 2 ? /Selesaikan aktiviti/ : /Sambung video/ }));
    }
    expect(markDone).toHaveBeenCalledWith("video");
    expect(screen.getByText("2 daripada 3 jawapan betul.")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: /Cuba lagi/ }));
    expect(screen.getByText("0 / 3 soalan selesai")).toBeInTheDocument();
  });
});
describe("Real YouTube playback", () => {
  it("pauses the YouTube video at each cue time and scores 10 marks per correct answer", async () => {
    vi.useFakeTimers();
    let time = 0;
    const pause = vi.fn(), playV = vi.fn();
    let events: { onReady: () => void } | undefined;
    (window as unknown as { YT: unknown }).YT = {
      Player: class {
        constructor(_el: HTMLElement, opts: { events: { onReady: () => void } }) { events = opts.events; }
        getCurrentTime = () => time; getDuration = () => 120;
        pauseVideo = pause; playVideo = playV; seekTo = vi.fn(); destroy = vi.fn();
      },
    };
    const { act } = await import("@testing-library/react");
    render(<InteractiveVideo url="https://youtu.be/fICWh8jp00k" />);
    await act(async () => { await Promise.resolve(); });
    act(() => events?.onReady());
    expect(screen.queryByRole("button", { name: /Soalan seterusnya/ })).toBeNull();
    time = 10; act(() => { vi.advanceTimersByTime(400); });
    expect(screen.queryByText("Soalan 1 daripada 3")).toBeNull();
    for (const [i, t] of [20, 45, 70].entries()) {
      time = t; act(() => { vi.advanceTimersByTime(400); });
      expect(screen.getByText(`Soalan ${i + 1} daripada 3`)).toBeInTheDocument();
      expect(pause).toHaveBeenCalledTimes(i + 1);
      const cue = VIDEO_CUES[i]!;
      const ans = i === 1 ? (cue.answer + 1) % 3 : cue.answer;
      fireEvent.click(screen.getByRole("button", { name: `${String.fromCharCode(65 + ans)}. ${cue.options[ans]}` }));
      fireEvent.click(screen.getByRole("button", { name: i === 2 ? /Selesaikan aktiviti/ : /Sambung video/ }));
    }
    expect(screen.getByTestId("markah")).toHaveTextContent("20 / 30");
    expect(screen.getByTestId("skor")).toHaveTextContent("67%");
    expect(markDone).toHaveBeenCalledWith("video");
    vi.useRealTimers();
  });
});
